import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema with roles
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  role: text("role").notNull().default("employee"), // admin, manager, employee
  status: text("status").notNull().default("offline"), // online, offline, away, busy
  lastLogin: timestamp("last_login"),
  lastLogout: timestamp("last_logout"),
  avatarUrl: text("avatar_url"),
  backgroundUrl: text("background_url"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  lastLogin: true,
  lastLogout: true,
  status: true,
});

// Task schema
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  priority: text("priority").notNull().default("medium"), // low, medium, high, urgent
  status: text("status").notNull().default("todo"), // todo, in-progress, completed
  dueDate: timestamp("due_date"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  assignedById: integer("assigned_by_id").notNull(),
  assignedToId: integer("assigned_to_id").notNull(),
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true, 
  createdAt: true,
});

// Room schema
export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // personal, meeting, break
  ownerId: integer("owner_id"),
  isLocked: boolean("is_locked").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  description: text("description"),
  iconType: text("icon_type").notNull().default("briefcase"), // briefcase, users, coffee, etc.
});

export const insertRoomSchema = createInsertSchema(rooms).omit({
  id: true, 
  createdAt: true,
});

// Knock Request schema
export const knockRequests = pgTable("knock_requests", {
  id: serial("id").primaryKey(),
  fromUserId: integer("from_user_id").notNull(),
  toRoomId: integer("to_room_id").notNull(),
  status: text("status").notNull().default("pending"), // pending, accepted, rejected
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertKnockRequestSchema = createInsertSchema(knockRequests).omit({
  id: true, 
  createdAt: true,
  status: true,
});

// Meeting schema
export const meetings = pgTable("meetings", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  roomId: integer("room_id"),
  createdById: integer("created_by_id").notNull(),
  meetingUrl: text("meeting_url"),
});

export const insertMeetingSchema = createInsertSchema(meetings).omit({
  id: true
});

// Notification schema
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // task, knock, meeting, system
  message: text("message").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  relatedId: integer("related_id"), // ID related to the notification (task ID, room ID, etc.)
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true, 
  createdAt: true,
  isRead: true,
});

// Room Participants schema (for tracking who is in which room)
export const roomParticipants = pgTable("room_participants", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id").notNull(),
  userId: integer("user_id").notNull(),
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
});

export const insertRoomParticipantSchema = createInsertSchema(roomParticipants).omit({
  id: true, 
  joinedAt: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;

export type Room = typeof rooms.$inferSelect;
export type InsertRoom = z.infer<typeof insertRoomSchema>;

export type KnockRequest = typeof knockRequests.$inferSelect;
export type InsertKnockRequest = z.infer<typeof insertKnockRequestSchema>;

export type Meeting = typeof meetings.$inferSelect;
export type InsertMeeting = z.infer<typeof insertMeetingSchema>;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

export type RoomParticipant = typeof roomParticipants.$inferSelect;
export type InsertRoomParticipant = z.infer<typeof insertRoomParticipantSchema>;
