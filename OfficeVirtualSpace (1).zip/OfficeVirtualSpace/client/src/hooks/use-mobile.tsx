import { useState, useEffect } from "react";

export function useIsMobile() {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    // Check if window is defined (for SSR)
    if (typeof window !== "undefined") {
      const checkMobile = () => {
        setIsMobile(window.innerWidth < 768);
      };
      
      // Set initial value
      checkMobile();
      
      // Add event listener for resize
      window.addEventListener("resize", checkMobile);
      
      // Cleanup
      return () => window.removeEventListener("resize", checkMobile);
    }
  }, []);

  return isMobile;
}