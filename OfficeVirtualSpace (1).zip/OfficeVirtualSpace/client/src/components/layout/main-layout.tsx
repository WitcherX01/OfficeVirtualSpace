import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useWebSocket } from "@/lib/websocket";
import { useIsMobile } from "@/hooks/use-mobile";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

// Icons
import {
  Menu,
  ChevronDown,
  Grid3X3,
  Home,
  Users,
  CheckSquare,
  Coffee,
  Bell,
  LogOut,
  Building2,
  Settings,
  User,
} from "lucide-react";

interface MainLayoutProps {
  children: React.ReactNode;
}

interface NavItemProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick?: () => void;
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase();
}

export function MainLayout({ children }: MainLayoutProps) {
  const [location] = useLocation();
  const { user, logoutMutation, updateStatusMutation } = useAuth();
  const isMobile = useIsMobile();
  const [menuOpen, setMenuOpen] = useState(false);
  const [statusDialogOpen, setStatusDialogOpen] = useState(false);
  const { notifications, onlineUsers } = useWebSocket();

  const navItems = [
    {
      href: "/",
      icon: <Home className="h-5 w-5" />,
      label: "Dashboard",
    },
    {
      href: "/my-office",
      icon: <Building2 className="h-5 w-5" />,
      label: "My Office",
    },
    {
      href: "/rooms",
      icon: <Users className="h-5 w-5" />,
      label: "Rooms",
    },
    {
      href: "/tasks",
      icon: <CheckSquare className="h-5 w-5" />,
      label: "Tasks",
    },
    {
      href: "/break-room",
      icon: <Coffee className="h-5 w-5" />,
      label: "Break Room",
    },
  ];

  // Status options for the user
  const statusOptions = [
    { value: "available", label: "Available", color: "bg-green-500" },
    { value: "busy", label: "Busy", color: "bg-red-500" },
    { value: "meeting", label: "In a Meeting", color: "bg-purple-500" },
    { value: "break", label: "On Break", color: "bg-yellow-500" },
    { value: "away", label: "Away", color: "bg-gray-500" },
  ];

  // Get current user status
  const currentStatus = statusOptions.find(
    (status) => status.value === user?.status
  ) || statusOptions[0];

  // Handle status change
  const handleStatusChange = (status: string) => {
    updateStatusMutation.mutate({ status });
    setStatusDialogOpen(false);
  };

  // Handle logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Render the navbar for desktop view
  const renderDesktopNav = () => (
    <aside className="hidden md:flex h-screen w-64 flex-col bg-white border-r">
      <div className="px-6 py-5 border-b">
        <h1 className="text-xl font-bold text-primary">Digital Office</h1>
      </div>

      <div className="px-4 py-4">
        <div className="flex items-center space-x-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={user?.avatarUrl || ""} alt={user?.displayName} />
            <AvatarFallback>{getInitials(user?.displayName || "")}</AvatarFallback>
          </Avatar>
          <div>
            <p className="text-sm font-medium">{user?.displayName}</p>
            <div className="flex items-center mt-1">
              <div
                className={`h-2 w-2 rounded-full mr-1.5 ${currentStatus.color}`}
              />
              <button
                onClick={() => setStatusDialogOpen(true)}
                className="text-xs text-gray-500 hover:text-gray-900"
              >
                {currentStatus.label}
                <ChevronDown className="h-3 w-3 inline ml-0.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <ScrollArea className="flex-1 py-2">
        <nav className="space-y-1 px-2">
          {navItems.map((item) => (
            <NavItem
              key={item.href}
              href={item.href}
              icon={item.icon}
              label={item.label}
              active={location === item.href}
            />
          ))}
        </nav>
      </ScrollArea>

      <div className="border-t p-4">
        <Button
          variant="outline"
          className="w-full justify-start"
          onClick={handleLogout}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </Button>
      </div>
    </aside>
  );

  // Render mobile header and navigation
  const renderMobileNav = () => (
    <>
      <header className="md:hidden flex items-center justify-between p-4 border-b bg-white">
        <div className="flex items-center">
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0">
              <SheetHeader className="border-b p-4">
                <SheetTitle>Digital Office</SheetTitle>
              </SheetHeader>

              <div className="px-4 py-4 border-b">
                <div className="flex items-center space-x-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage
                      src={user?.avatarUrl || ""}
                      alt={user?.displayName}
                    />
                    <AvatarFallback>
                      {getInitials(user?.displayName || "")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">{user?.displayName}</p>
                    <div className="flex items-center mt-1">
                      <div
                        className={`h-2 w-2 rounded-full mr-1.5 ${currentStatus.color}`}
                      />
                      <button
                        onClick={() => {
                          setMenuOpen(false);
                          setStatusDialogOpen(true);
                        }}
                        className="text-xs text-gray-500 hover:text-gray-900"
                      >
                        {currentStatus.label}
                        <ChevronDown className="h-3 w-3 inline ml-0.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <ScrollArea className="flex-1 py-2 h-[calc(100vh-8rem)]">
                <nav className="space-y-1 px-2">
                  {navItems.map((item) => (
                    <NavItem
                      key={item.href}
                      href={item.href}
                      icon={item.icon}
                      label={item.label}
                      active={location === item.href}
                      onClick={() => setMenuOpen(false)}
                    />
                  ))}
                </nav>
              </ScrollArea>

              <div className="border-t p-4">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={handleLogout}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </Button>
              </div>
            </SheetContent>
          </Sheet>
          <h1 className="text-xl font-bold text-primary ml-3">
            {navItems.find((item) => item.href === location)?.label || "Digital Office"}
          </h1>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              {notifications.length > 0 && (
                <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500" />
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-72">
            <DropdownMenuLabel>Notifications</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {notifications.length === 0 ? (
              <div className="py-2 px-4 text-sm text-gray-500">
                No new notifications
              </div>
            ) : (
              <ScrollArea className="h-64">
                {notifications.map((notification: any, index: number) => (
                  <div
                    key={index}
                    className="py-2 px-4 hover:bg-gray-100 cursor-pointer"
                  >
                    <p className="text-sm font-medium">{notification.title}</p>
                    <p className="text-xs text-gray-500">{notification.message}</p>
                  </div>
                ))}
              </ScrollArea>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </header>
    </>
  );

  return (
    <div className="flex min-h-screen bg-gray-100 dark:bg-gray-900">
      {renderDesktopNav()}
      <div className="flex-1 flex flex-col">
        {renderMobileNav()}
        <main className="flex-1 p-4 md:p-6">{children}</main>
      </div>

      {/* Status Dialog */}
      <Dialog open={statusDialogOpen} onOpenChange={setStatusDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Update Status</DialogTitle>
            <DialogDescription>
              Set your current status to let others know your availability.
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 gap-4 py-4">
            {statusOptions.map((status) => (
              <Button
                key={status.value}
                variant="outline"
                className="w-full justify-start"
                onClick={() => handleStatusChange(status.value)}
              >
                <div
                  className={`h-3 w-3 rounded-full ${status.color} mr-2`}
                ></div>
                {status.label}
              </Button>
            ))}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setStatusDialogOpen(false)}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Navigation item component
function NavItem({ href, icon, label, active, onClick }: NavItemProps) {
  return (
    <div
      onClick={() => {
        if (onClick) onClick();
        window.location.href = href;
      }}
      className={`flex items-center space-x-3 px-3 py-2 rounded-md text-sm cursor-pointer ${
        active
          ? "bg-primary text-primary-foreground"
          : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
      }`}
    >
      {icon}
      <span>{label}</span>
    </div>
  );
}