import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useWebSocket } from "@/lib/websocket";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

import {
  Home,
  Briefcase,
  CheckSquare,
  DoorOpen,
  Users,
  MessageSquare,
  Coffee,
  Clock,
  LogOut,
  User,
  ChevronDown
} from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation, updateStatusMutation } = useAuth();
  
  if (!user) return null;
  
  const isActive = (path: string) => {
    return location === path;
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const handleStatusChange = (status: string) => {
    updateStatusMutation.mutate({ status });
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
        return "bg-green-400";
      case "busy":
        return "bg-red-400";
      case "away":
        return "bg-yellow-400";
      default:
        return "bg-gray-400";
    }
  };
  
  const getStatusText = (status: string) => {
    switch (status) {
      case "online":
        return "Online";
      case "busy":
        return "Busy";
      case "away":
        return "Away";
      default:
        return "Offline";
    }
  };

  return (
    <div className="hidden md:flex md:flex-shrink-0">
      <div className="flex flex-col w-64 bg-gray-900 text-white">
        <div className="flex items-center justify-center h-16 bg-gray-900">
          <h1 className="text-xl font-semibold">Digital Office</h1>
        </div>
        <div className="flex flex-col flex-grow overflow-y-auto">
          <nav className="flex-1 px-2 py-4 space-y-1">
            {/* User Profile */}
            <div className="flex items-center px-4 py-3 mb-6 bg-gray-800 rounded-lg">
              <Avatar className="h-10 w-10">
                <AvatarImage src={user.avatarUrl} />
                <AvatarFallback>{user.displayName.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <div className="text-sm font-medium">{user.displayName}</div>
                <div className="text-xs text-gray-400">{user.role}</div>
              </div>
              <div className="ml-auto">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <span className={`inline-block h-2 w-2 rounded-full ${getStatusColor(user.status)}`}></span>
                      <ChevronDown className="h-4 w-4 ml-1" />
                      <span className="sr-only">Status</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleStatusChange("online")}>
                      <span className="h-2 w-2 rounded-full bg-green-400 mr-2"></span>
                      <span>Online</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleStatusChange("busy")}>
                      <span className="h-2 w-2 rounded-full bg-red-400 mr-2"></span>
                      <span>Busy</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleStatusChange("away")}>
                      <span className="h-2 w-2 rounded-full bg-yellow-400 mr-2"></span>
                      <span>Away</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleStatusChange("offline")}>
                      <span className="h-2 w-2 rounded-full bg-gray-400 mr-2"></span>
                      <span>Appear Offline</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>

            {/* Nav Items */}
            <Link href="/">
              <a className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg ${isActive("/") ? "bg-gray-700" : "text-gray-300 hover:bg-gray-700"}`}>
                <Home className="h-5 w-5 mr-3 text-gray-400" />
                Dashboard
              </a>
            </Link>

            <Link href="/my-office">
              <a className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg ${isActive("/my-office") ? "bg-gray-700" : "text-gray-300 hover:bg-gray-700"}`}>
                <Briefcase className="h-5 w-5 mr-3 text-gray-400" />
                My Office
              </a>
            </Link>

            <Link href="/tasks">
              <a className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg ${isActive("/tasks") ? "bg-gray-700" : "text-gray-300 hover:bg-gray-700"}`}>
                <CheckSquare className="h-5 w-5 mr-3 text-gray-400" />
                Tasks
              </a>
            </Link>

            <Link href="/rooms">
              <a className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg ${isActive("/rooms") || location.startsWith("/rooms/") ? "bg-gray-700" : "text-gray-300 hover:bg-gray-700"}`}>
                <DoorOpen className="h-5 w-5 mr-3 text-gray-400" />
                Rooms
              </a>
            </Link>

            <Link href="/team">
              <a className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg ${isActive("/team") ? "bg-gray-700" : "text-gray-300 hover:bg-gray-700"}`}>
                <Users className="h-5 w-5 mr-3 text-gray-400" />
                Team
              </a>
            </Link>

            <Link href="/chat">
              <a className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg ${isActive("/chat") ? "bg-gray-700" : "text-gray-300 hover:bg-gray-700"}`}>
                <MessageSquare className="h-5 w-5 mr-3 text-gray-400" />
                Chat
              </a>
            </Link>

            <Link href="/break-room">
              <a className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg ${isActive("/break-room") ? "bg-gray-700" : "text-gray-300 hover:bg-gray-700"}`}>
                <Coffee className="h-5 w-5 mr-3 text-gray-400" />
                Break Room
              </a>
            </Link>
          </nav>

          <div className="px-4 py-4">
            <div className="flex items-center">
              <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                <Clock className="inline-block h-4 w-4 mr-2" />
                Work Hours
              </div>
            </div>
            <div className="mt-2 text-sm text-gray-300 flex items-center justify-between">
              <span>9:00 AM - 5:00 PM</span>
              <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-500 text-white">
                Active
              </span>
            </div>
          </div>

          <div className="px-4 py-4 border-t border-gray-700">
            <button 
              className="flex items-center text-sm text-gray-400 hover:text-white"
              onClick={handleLogout}
            >
              <LogOut className="h-5 w-5 mr-2" />
              Log out
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
