import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useWebSocket } from "@/lib/websocket";
import { Bell, Mail, Plus, Menu, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import Sidebar from "./sidebar";

interface TopbarProps {
  onNewTaskClick?: () => void;
}

export default function Topbar({ onNewTaskClick }: TopbarProps) {
  const { user } = useAuth();
  const { notifications } = useWebSocket();
  
  const unreadNotifications = notifications?.filter(n => !n.isRead) || [];
  
  return (
    <div className="relative z-10 flex-shrink-0 flex h-16 bg-white shadow">
      <Sheet>
        <SheetTrigger asChild>
          <button className="px-4 border-r border-gray-200 text-gray-500 focus:outline-none focus:bg-gray-100 focus:text-gray-600 md:hidden">
            <Menu className="h-6 w-6" />
          </button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0 bg-gray-900 text-white" style={{ width: "256px", maxWidth: "80vw" }}>
          <Sidebar />
        </SheetContent>
      </Sheet>
      
      <div className="flex-1 px-4 flex justify-between">
        <div className="flex-1 flex">
          <div className="w-full flex md:ml-0">
            <div className="relative w-full text-gray-400 focus-within:text-gray-600">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3">
                <Search className="h-5 w-5" />
              </div>
              <Input 
                className="block w-full h-full pl-10 pr-3 py-2 rounded-md text-gray-900 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 sm:text-sm border-0" 
                placeholder="Search..."
              />
            </div>
          </div>
        </div>
        <div className="ml-4 flex items-center md:ml-6">
          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5 text-gray-400" />
                {unreadNotifications.length > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs">
                    {unreadNotifications.length}
                  </Badge>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <DropdownMenuLabel>Notifications</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {notifications && notifications.length > 0 ? (
                notifications.slice(0, 5).map((notification) => (
                  <DropdownMenuItem key={notification.id} className="p-3 cursor-pointer">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 mr-3">
                        {notification.type === 'task' && <Bell className="h-5 w-5 text-blue-500" />}
                        {notification.type === 'knock' && <Mail className="h-5 w-5 text-green-500" />}
                        {notification.type === 'meeting' && <Bell className="h-5 w-5 text-purple-500" />}
                      </div>
                      <div className="flex-1">
                        <p className={`text-sm ${notification.isRead ? 'text-gray-600' : 'text-gray-900 font-medium'}`}>
                          {notification.message}
                        </p>
                        <p className="text-xs text-gray-500">
                          {new Date(notification.createdAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                      </div>
                    </div>
                  </DropdownMenuItem>
                ))
              ) : (
                <div className="p-4 text-center text-gray-500">
                  No notifications
                </div>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem className="p-2 justify-center">
                <Link href="/notifications">
                  <a className="text-primary text-sm">View all notifications</a>
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          {/* Messages */}
          <span className="ml-3 relative">
            <Button variant="ghost" size="icon" className="relative">
              <Mail className="h-5 w-5 text-gray-400" />
              <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-400"></span>
            </Button>
          </span>
          
          {/* Quick Actions */}
          {onNewTaskClick && (
            <div className="ml-3 relative">
              <Button 
                className="flex text-sm bg-primary text-white px-4 py-2 rounded-md hover:bg-blue-600"
                onClick={onNewTaskClick}
              >
                <Plus className="h-4 w-4 mr-2" />
                New Task
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
