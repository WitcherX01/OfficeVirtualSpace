import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { X, Send, Maximize2, Minimize2, MessageSquare } from "lucide-react";

// TypeScript types for our component
interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export function AIAssistant() {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Namaste sahab! Main Ramukaka, aapka digital peon hoon. Kya seva karoon aaj?",
      timestamp: new Date(),
    },
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom of messages when new messages are added
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    // Add user message to chat
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: message,
      timestamp: new Date(),
    };
    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setMessage("");

    // Add AI response after a short delay to simulate thinking
    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: generateResponse(message),
        timestamp: new Date(),
      };
      setMessages((prevMessages) => [...prevMessages, assistantMessage]);
    }, 1000);
  };

  // Generate a simple response based on user input
  const generateResponse = (input: string): string => {
    const lowerInput = input.toLowerCase();
    
    // Patterns for common queries
    if (lowerInput.includes("hello") || lowerInput.includes("hi") || lowerInput.includes("hey")) {
      return `Namaste ${user?.displayName || "sahab"}! Main aapki kya madad kar sakta hoon?`;
    }
    
    if (lowerInput.includes("tea") || lowerInput.includes("chai") || lowerInput.includes("coffee")) {
      return "Ji sahab! Ekdum kadak chai abhi laata hoon. 2 minute dijiye!";
    }
    
    if (lowerInput.includes("meeting") || lowerInput.includes("schedule")) {
      return "Meeting ke liye Rooms section pe jaiye sahab. Wahaan se meeting create kar sakte hain. Koi madad chahiye to batayein?";
    }
    
    if (lowerInput.includes("task") || lowerInput.includes("todo")) {
      return "Tasks section mein aap apna kaam dekh sakte hain, sahab. Wahaan se tasks assign aur track kar sakte hain. Koi vishesh task hai jisme madad chahiye?";
    }
    
    if (lowerInput.includes("break") || lowerInput.includes("game")) {
      return "Break Room mein jaiye sahab. Wahaan khel sakte hain aur dosto se baatein kar sakte hain. Break time mein mazaa aayega!";
    }
    
    if (lowerInput.includes("problem") || lowerInput.includes("issue") || lowerInput.includes("help")) {
      return "Main aapki seva mein hazir hoon sahab! Aap apni pareshani batayein, main jaldi se samadhan nikaalunga.";
    }

    if (lowerInput.includes("thank")) {
      return "Arey sahab, shukriya ki kya baat hai. Yeh to mera farz hai. Koi aur seva ho to batayein!";
    }
    
    // Default responses
    const defaultResponses = [
      "Ji sahab, main samajh gaya. Main aapki madad karta hoon.",
      "Bada acha sawal pucha hai aapne. Main aapko batata hoon.",
      "Main aapke sawaal par dhyan de raha hoon. Aur kuch madad chahiye sahab?",
      "Main Ramukaka hoon, aapka digital peon. Aap mujhe koi bhi kaam bata sakte hain.",
      "Main dekhta hoon sahab. Kuch vishesh jaankari chahiye aapko?",
    ];
    
    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
  };

  // Toggle chat window
  const toggleChat = () => {
    setIsOpen(!isOpen);
    setIsMinimized(false);
  };

  // Toggle minimize/maximize
  const toggleMinimize = () => {
    setIsMinimized(!isMinimized);
  };

  // Format timestamp for display
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <>
      {/* Chat Button */}
      {!isOpen && (
        <Button
          onClick={toggleChat}
          className="fixed bottom-4 right-4 rounded-full p-3 shadow-lg bg-primary hover:bg-primary/90"
        >
          <MessageSquare className="h-6 w-6" />
        </Button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div
          className={`fixed ${
            isMinimized ? "bottom-4 right-4 w-auto h-auto" : "bottom-4 right-4 w-80 h-96"
          } bg-white dark:bg-slate-800 rounded-lg shadow-xl transition-all duration-200 flex flex-col overflow-hidden border dark:border-slate-700`}
        >
          {/* Chat Header */}
          <div className="bg-primary text-white p-3 flex items-center justify-between">
            {isMinimized ? (
              <div onClick={toggleMinimize} className="flex items-center cursor-pointer">
                <span className="font-medium">Ramukaka</span>
              </div>
            ) : (
              <div className="flex items-center">
                <Avatar className="h-8 w-8 mr-2">
                  <AvatarImage src="/assets/ramukaka.png" alt="Ramukaka" />
                  <AvatarFallback className="bg-primary-foreground text-primary">RK</AvatarFallback>
                </Avatar>
                <span className="font-medium">Ramukaka</span>
              </div>
            )}
            <div className="flex items-center space-x-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleMinimize}
                className="h-6 w-6 text-white hover:bg-primary-foreground/10"
              >
                {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleChat}
                className="h-6 w-6 text-white hover:bg-primary-foreground/10"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Chat Body */}
          {!isMinimized && (
            <>
              <ScrollArea className="flex-1 p-3">
                <div className="space-y-4">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${
                        msg.role === "user" ? "justify-end" : "justify-start"
                      }`}
                    >
                      <div
                        className={`max-w-[80%] rounded-lg p-3 ${
                          msg.role === "user"
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted dark:bg-slate-700 text-gray-800 dark:text-gray-100"
                        }`}
                      >
                        <div className="flex justify-between items-start mb-1">
                          <span className="font-medium text-xs">
                            {msg.role === "user" ? "You" : "Ramukaka"}
                          </span>
                          <span className="text-xs opacity-70 ml-2">
                            {formatTime(msg.timestamp)}
                          </span>
                        </div>
                        <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>

              {/* Chat Input */}
              <div className="p-3 border-t dark:border-slate-700">
                <form onSubmit={handleSubmit} className="flex gap-2">
                  <Input
                    placeholder="Type a message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="flex-1 dark:bg-slate-700 dark:border-slate-600 dark:text-white"
                  />
                  <Button type="submit" size="icon" disabled={!message.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </form>
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
}