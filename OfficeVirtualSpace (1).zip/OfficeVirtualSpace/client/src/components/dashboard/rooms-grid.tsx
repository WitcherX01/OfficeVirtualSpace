import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useWebSocket } from "@/lib/websocket";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import RoomCard from "@/components/rooms/room-card";

interface RoomsGridProps {
  rooms: any[];
}

export default function RoomsGrid({ rooms }: RoomsGridProps) {
  const { user } = useAuth();
  const { knockOnDoor } = useWebSocket();
  const [_, navigate] = useLocation();
  
  if (!user) return null;
  
  // Filter rooms to prioritize my personal office, then recently active, and limit to 4
  const sortedRooms = [...rooms].sort((a, b) => {
    // My personal office first
    if (a.ownerId === user.id && a.type === "personal") return -1;
    if (b.ownerId === user.id && b.type === "personal") return 1;
    
    // Rooms with participants next
    if ((a.participantCount || 0) > 0 && (b.participantCount || 0) === 0) return -1;
    if ((a.participantCount || 0) === 0 && (b.participantCount || 0) > 0) return 1;
    
    // Then sort by participant count
    return (b.participantCount || 0) - (a.participantCount || 0);
  });
  
  const displayRooms = sortedRooms.slice(0, 4);
  
  const handleEnterRoom = (roomId: number) => {
    navigate(`/rooms/${roomId}`);
  };
  
  const handleKnock = (roomId: number) => {
    knockOnDoor(roomId);
  };
  
  return (
    <Card className="bg-white shadow rounded-lg">
      <CardHeader className="px-4 py-5 border-b border-gray-200 sm:px-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium leading-6 text-gray-900">Office Rooms</h3>
          <Link href="/rooms">
            <a className="text-sm text-primary hover:text-blue-700">
              Create Room
            </a>
          </Link>
        </div>
      </CardHeader>
      <CardContent className="p-4 grid grid-cols-1 gap-4 sm:grid-cols-2 max-h-96 overflow-y-auto scrollbar-hide">
        {displayRooms.length === 0 ? (
          <div className="sm:col-span-2 text-center py-6 text-gray-500">
            No rooms available
          </div>
        ) : (
          displayRooms.map((room) => (
            <RoomCard 
              key={room.id} 
              room={room}
              onEnter={() => handleEnterRoom(room.id)}
              onKnock={() => handleKnock(room.id)}
              currentUserId={user.id}
              compact
            />
          ))
        )}
      </CardContent>
    </Card>
  );
}
