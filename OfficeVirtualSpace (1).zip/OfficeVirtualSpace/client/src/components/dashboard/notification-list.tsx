import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface NotificationListProps {
  notifications: any[];
}

export default function NotificationList({ notifications }: NotificationListProps) {
  // Mark notification as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("PATCH", `/api/notifications/${id}/read`, {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    }
  });
  
  // Sort notifications by time and unread status
  const sortedNotifications = [...notifications].sort((a, b) => {
    // Unread notifications first
    if (!a.isRead && b.isRead) return -1;
    if (a.isRead && !b.isRead) return 1;
    
    // Then by creation time
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });
  
  // Get only the latest 5 notifications
  const displayNotifications = sortedNotifications.slice(0, 5);
  
  const handleMarkAsRead = (id: number) => {
    markAsReadMutation.mutate(id);
  };
  
  const formatNotificationTime = (timestamp: string) => {
    const now = new Date();
    const notificationTime = new Date(timestamp);
    const diffMs = now.getTime() - notificationTime.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minute${diffMins !== 1 ? 's' : ''} ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
    
    const diffDays = Math.floor(diffHours / 24);
    if (diffDays < 7) return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
    
    return notificationTime.toLocaleDateString();
  };
  
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'task':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
          </svg>
        );
      case 'knock':
      case 'knock_response':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
        );
      case 'meeting':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
        );
      case 'task_completed':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        );
      default:
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
          </svg>
        );
    }
  };

  return (
    <Card className="bg-white shadow rounded-lg h-full">
      <CardHeader className="px-4 py-5 border-b border-gray-200 sm:px-6">
        <h3 className="text-lg font-medium leading-6 text-gray-900">Notifications</h3>
      </CardHeader>
      <ul className="divide-y divide-gray-200 max-h-80 overflow-y-auto scrollbar-hide">
        {displayNotifications.length === 0 ? (
          <li className="px-4 py-6 text-center text-gray-500">
            No notifications yet
          </li>
        ) : (
          displayNotifications.map((notification) => (
            <li key={notification.id} className={`px-4 py-4 ${!notification.isRead ? "bg-blue-50" : ""}`}>
              <div className="flex">
                <div className="flex-shrink-0">
                  {getNotificationIcon(notification.type)}
                </div>
                <div className="ml-3">
                  <p className={`text-sm text-gray-900 ${!notification.isRead ? "font-medium" : ""}`}>
                    {notification.message}
                  </p>
                  <p className="text-xs text-gray-500">{formatNotificationTime(notification.createdAt)}</p>
                  
                  {notification.type === 'knock' && (
                    <div className="mt-2 flex space-x-2">
                      <Button size="sm" variant="default" className="text-xs">Accept</Button>
                      <Button size="sm" variant="outline" className="text-xs">Decline</Button>
                    </div>
                  )}
                  
                  {!notification.isRead && (
                    <Button 
                      variant="link" 
                      size="sm" 
                      className="mt-1 p-0 h-auto text-xs"
                      onClick={() => handleMarkAsRead(notification.id)}
                    >
                      Mark as read
                    </Button>
                  )}
                </div>
              </div>
            </li>
          ))
        )}
      </ul>
      <CardContent className="px-4 py-4 border-t border-gray-200 text-center">
        <Button variant="link" className="text-sm text-primary hover:text-blue-700">
          View all notifications
        </Button>
      </CardContent>
    </Card>
  );
}
