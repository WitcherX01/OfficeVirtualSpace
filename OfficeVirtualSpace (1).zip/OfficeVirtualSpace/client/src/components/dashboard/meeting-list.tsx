import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface MeetingListProps {
  meetings: any[];
}

export default function MeetingList({ meetings }: MeetingListProps) {
  const now = new Date();
  
  // Sort meetings by start time and filter out past meetings
  const upcomingMeetings = meetings
    .filter(meeting => new Date(meeting.startTime) > now)
    .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());
  
  const isStartingSoon = (startTime: string) => {
    const meetingTime = new Date(startTime);
    const diffMs = meetingTime.getTime() - now.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    return diffMins <= 15; // 15 minutes or less
  };
  
  const formatMeetingTime = (startTime: string, endTime: string) => {
    const start = new Date(startTime);
    const end = new Date(endTime);
    
    const sameDay = start.toDateString() === end.toDateString();
    const isToday = start.toDateString() === now.toDateString();
    const isTomorrow = new Date(now.getTime() + 86400000).toDateString() === start.toDateString();
    
    const dateString = isToday ? 'Today' : isTomorrow ? 'Tomorrow' : start.toLocaleDateString();
    
    return `${dateString}, ${start.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - ${end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  };

  return (
    <Card className="bg-white shadow rounded-lg">
      <CardHeader className="px-4 py-5 border-b border-gray-200 sm:px-6">
        <h3 className="text-lg font-medium leading-6 text-gray-900">Upcoming Meetings</h3>
      </CardHeader>
      <ul className="divide-y divide-gray-200">
        {upcomingMeetings.length === 0 ? (
          <li className="px-4 py-6 text-center text-gray-500">
            No upcoming meetings scheduled
          </li>
        ) : (
          upcomingMeetings.slice(0, 3).map((meeting) => (
            <li key={meeting.id} className="px-4 py-4 flex items-center">
              <div className="min-w-0 flex-1 flex items-center">
                <div className={`flex-shrink-0 p-2 rounded-md ${
                  isStartingSoon(meeting.startTime) ? "bg-red-50" : "bg-blue-50"
                }`}>
                  <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${
                    isStartingSoon(meeting.startTime) ? "text-red-500" : "text-blue-500"
                  }`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                </div>
                <div className="min-w-0 flex-1 px-4">
                  <div>
                    <p className="text-sm font-medium text-gray-900 truncate">{meeting.title}</p>
                    <p className="text-sm text-gray-500">
                      {formatMeetingTime(meeting.startTime, meeting.endTime)}
                    </p>
                  </div>
                </div>
              </div>
              <div>
                {isStartingSoon(meeting.startTime) ? (
                  <Button className="inline-flex items-center px-3 py-1 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-primary hover:bg-blue-700">
                    Join
                  </Button>
                ) : (
                  <Button variant="outline" className="inline-flex items-center px-3 py-1 border border-gray-300 text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    Details
                  </Button>
                )}
              </div>
            </li>
          ))
        )}
      </ul>
    </Card>
  );
}
