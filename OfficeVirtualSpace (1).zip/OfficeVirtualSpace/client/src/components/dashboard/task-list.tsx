import { useState } from "react";
import { Link } from "wouter";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

interface TaskListProps {
  tasks: any[];
}

export default function TaskList({ tasks }: TaskListProps) {
  // Update task status mutation
  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number, status: string }) => {
      const res = await apiRequest("PATCH", `/api/tasks/${id}`, { status });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    }
  });
  
  const handleStatusChange = (task: any) => {
    const newStatus = task.status === "completed" ? "in-progress" : "completed";
    updateTaskMutation.mutate({ id: task.id, status: newStatus });
  };
  
  // Sort tasks by priority and due date
  const sortedTasks = [...tasks].sort((a, b) => {
    // First by status: todo and in-progress at the top
    if (a.status !== "completed" && b.status === "completed") return -1;
    if (a.status === "completed" && b.status !== "completed") return 1;
    
    // Then by priority
    const priorityOrder = { "urgent": 0, "high": 1, "medium": 2, "low": 3 };
    if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    }
    
    // Then by due date if both have due dates
    if (a.dueDate && b.dueDate) {
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    }
    
    // Tasks with due dates come before tasks without due dates
    if (a.dueDate && !b.dueDate) return -1;
    if (!a.dueDate && b.dueDate) return 1;
    
    return 0;
  });
  
  // Limit to 5 tasks for the dashboard
  const displayTasks = sortedTasks.slice(0, 5);

  return (
    <Card className="bg-white shadow rounded-lg">
      <CardHeader className="px-4 py-5 border-b border-gray-200 sm:px-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium leading-6 text-gray-900">Today's Tasks</h3>
          <Link href="/tasks">
            <a className="text-sm text-primary hover:text-blue-700">
              View All
            </a>
          </Link>
        </div>
      </CardHeader>
      <ul className="divide-y divide-gray-200 max-h-96 overflow-y-auto scrollbar-hide">
        {displayTasks.length === 0 ? (
          <li className="px-4 py-6 text-center text-gray-500">
            No tasks assigned for today
          </li>
        ) : (
          displayTasks.map((task) => (
            <li key={task.id} className="px-4 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Checkbox 
                    id={`task-${task.id}`}
                    checked={task.status === "completed"}
                    onCheckedChange={() => handleStatusChange(task)}
                  />
                  <span className={`ml-3 block ${task.status === "completed" ? "line-through text-gray-500" : ""}`}>
                    <span className="text-sm font-medium text-gray-900">{task.title}</span>
                    <span className="block text-xs text-gray-500">
                      {task.dueDate ? (
                        <>Due {new Date(task.dueDate).toLocaleDateString()} at {new Date(task.dueDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</>
                      ) : (
                        "No due date"
                      )}
                    </span>
                  </span>
                </div>
                <div>
                  <Badge 
                    className={
                      task.status === "in-progress" ? "bg-yellow-100 text-yellow-800" :
                      task.status === "completed" ? "bg-green-100 text-green-800" :
                      task.priority === "urgent" ? "bg-red-100 text-red-800" :
                      task.priority === "high" ? "bg-orange-100 text-orange-800" :
                      "bg-blue-100 text-blue-800"
                    }
                  >
                    {task.status === "in-progress" ? "In Progress" :
                     task.status === "completed" ? "Completed" :
                     task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                  </Badge>
                </div>
              </div>
            </li>
          ))
        )}
      </ul>
      <CardContent className="px-4 py-4 border-t border-gray-200">
        <Link href="/tasks">
          <a>
            <Button variant="ghost" className="flex items-center text-sm text-primary hover:text-blue-700">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Add new task
            </Button>
          </a>
        </Link>
      </CardContent>
    </Card>
  );
}
