import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface RoomCardProps {
  room: any;
  onEnter: () => void;
  onKnock: () => void;
  currentUserId: number;
  compact?: boolean;
}

export default function RoomCard({ room, onEnter, onKnock, currentUserId, compact = false }: RoomCardProps) {
  const isOwner = room.ownerId === currentUserId;
  const canDirectlyEnter = !room.isLocked || isOwner || room.type !== "personal";
  
  return (
    <div className={`relative rounded-lg border border-gray-300 bg-white p-4 shadow-sm hover:shadow ${compact ? 'h-full' : ''}`}>
      <div className="flex items-center">
        <div className={`w-10 h-10 flex items-center justify-center rounded-full
          ${room.iconType === "briefcase" ? "bg-blue-100" : 
            room.iconType === "users" ? "bg-purple-100" : 
            room.iconType === "coffee" ? "bg-red-100" : 
            "bg-green-100"}`}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className={`h-5 w-5
              ${room.iconType === "briefcase" ? "text-blue-600" :
                room.iconType === "users" ? "text-purple-600" :
                room.iconType === "coffee" ? "text-red-600" :
                "text-green-600"}`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            {room.iconType === "briefcase" && (
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
              />
            )}
            {room.iconType === "users" && (
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
              />
            )}
            {room.iconType === "coffee" && (
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M3 3h18v5.5c0 1.38-.56 2.63-1.46 3.54a4.98 4.98 0 01-3.55 1.46h-6c-1.59 0-3.01-.74-3.93-1.89a4.99 4.99 0 01-1.06-3.11V3zm11 19H8M14 10V4"
              />
            )}
            {room.iconType === "door-open" && (
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M8 9l4-4 4 4m0 6l-4 4-4-4"
              />
            )}
          </svg>
        </div>
        <div className="ml-3">
          <h3 className="text-sm font-medium text-gray-900">{room.name}</h3>
          <p className="text-xs text-gray-500">{room.description}</p>
        </div>
        <div className="ml-auto">
          {room.type === "personal" ? (
            <span className={`inline-block h-2 w-2 rounded-full ${isOwner ? "bg-green-400" : "bg-gray-400"}`}></span>
          ) : (
            <span className="inline-flex items-center justify-center h-5 w-5 rounded-full ring-2 ring-white bg-primary text-white text-xs">
              {room.participantCount || 0}
            </span>
          )}
        </div>
      </div>
      <div className="mt-3 flex justify-between items-center">
        <div>
          {room.type === "personal" && (
            <Badge variant="outline" className="text-xs">
              {isOwner ? "Your Office" : "Personal Office"}
            </Badge>
          )}
          {room.type === "meeting" && (
            <Badge variant="secondary" className="text-xs">
              Meeting Room
            </Badge>
          )}
          {room.type === "break" && (
            <Badge className="text-xs bg-red-100 text-red-800 hover:bg-red-100">
              Break Room
            </Badge>
          )}
        </div>
        <div>
          {canDirectlyEnter ? (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onEnter}
              className="text-xs text-primary hover:text-blue-700"
            >
              Enter
            </Button>
          ) : (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onKnock}
              className="text-xs text-gray-500 hover:text-gray-700"
            >
              Knock
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
