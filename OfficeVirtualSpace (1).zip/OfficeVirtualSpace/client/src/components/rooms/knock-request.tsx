import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useWebSocket } from "@/lib/websocket";

interface KnockRequestProps {
  knockRequest: {
    id: number;
    user: {
      id: number;
      displayName: string;
      username: string;
      status: string;
      avatarUrl?: string;
    };
    room: {
      id: number;
      name: string;
    };
  };
}

export default function KnockRequest({ knockRequest }: KnockRequestProps) {
  const { respondToKnock } = useWebSocket();
  
  const handleAccept = () => {
    respondToKnock(knockRequest.id, true);
  };
  
  const handleDecline = () => {
    respondToKnock(knockRequest.id, false);
  };
  
  return (
    <div className="p-3 border rounded-md bg-blue-50">
      <div className="flex items-start space-x-3">
        <Avatar>
          <AvatarImage src={knockRequest.user.avatarUrl} />
          <AvatarFallback>{knockRequest.user.displayName.charAt(0)}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <p className="text-sm font-medium">{knockRequest.user.displayName}</p>
          <p className="text-xs text-gray-500 mb-3">is knocking on your office door</p>
          <div className="flex space-x-2">
            <Button size="sm" onClick={handleAccept} variant="default">Accept</Button>
            <Button size="sm" onClick={handleDecline} variant="outline">Decline</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
