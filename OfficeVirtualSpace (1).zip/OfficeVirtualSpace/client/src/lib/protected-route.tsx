import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Redirect, Route } from "wouter";

export function ProtectedRoute({
  path,
  component: Component,
}: {
  path: string;
  component: React.ComponentType<any>;
}) {
  return (
    <Route path={path}>
      {(params) => {
        try {
          const { user, isLoading } = useAuth();

          // If we're still loading the user data
          if (isLoading) {
            return (
              <div className="flex items-center justify-center min-h-screen">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            );
          }

          // If not authenticated redirect to auth page
          if (!user) {
            return <Redirect to="/auth" />;
          }

          // If authenticated, render the component
          return <Component {...params} />;
        } catch (error) {
          console.error("Auth context error:", error);
          
          // In case of auth context error, show loading and don't redirect yet
          return (
            <div className="flex items-center justify-center min-h-screen">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          );
        }
      }}
    </Route>
  );
}
