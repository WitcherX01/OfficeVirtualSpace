import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';

type WebSocketContextType = {
  connected: boolean;
  sendMessage: (type: string, data: any) => void;
  roomParticipants: Map<number, any[]>;
  activeRoomId: number | null;
  joinRoom: (roomId: number) => void;
  leaveRoom: () => void;
  knockOnDoor: (roomId: number) => void;
  respondToKnock: (knockId: number, accepted: boolean) => void;
  knockRequests: any[];
  notifications: any[];
  sendRoomMessage: (message: string) => void;
  roomMessages: Map<number, any[]>;
  onlineUsers: Map<number, { status: string; displayName: string }>;
  connectWebSocket: (userId: number) => void;
};

const WebSocketContext = createContext<WebSocketContextType | null>(null);

// Default values for the WebSocket context when not connected
const defaultWebSocketValues: WebSocketContextType = {
  connected: false,
  sendMessage: () => {},
  roomParticipants: new Map(),
  activeRoomId: null,
  joinRoom: () => {},
  leaveRoom: () => {},
  knockOnDoor: () => {},
  respondToKnock: () => {},
  knockRequests: [],
  notifications: [],
  sendRoomMessage: () => {},
  roomMessages: new Map(),
  onlineUsers: new Map(),
  connectWebSocket: () => {},
};

export function WebsocketProvider({ children }: { children: ReactNode }) {
  // Get auth if we're in an authenticated component tree
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);
  const [roomParticipants, setRoomParticipants] = useState<Map<number, any[]>>(new Map());
  const [activeRoomId, setActiveRoomId] = useState<number | null>(null);
  const [knockRequests, setKnockRequests] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [roomMessages, setRoomMessages] = useState<Map<number, any[]>>(new Map());
  const [onlineUsers, setOnlineUsers] = useState<Map<number, { status: string; displayName: string }>>(new Map());

  // Manual connection function that can be called when user is authenticated
  const connectWebSocket = useCallback((userId: number) => {
    if (!userId) return;
    
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const newSocket = new WebSocket(wsUrl);

    newSocket.onopen = () => {
      setConnected(true);
      console.log('WebSocket connected');
      
      // Authenticate with the server
      newSocket.send(JSON.stringify({
        type: 'authenticate',
        data: { userId }
      }));
    };

    newSocket.onclose = () => {
      setConnected(false);
      console.log('WebSocket disconnected');
    };

    newSocket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    newSocket.onmessage = (event) => {
      const message = JSON.parse(event.data);
      console.log('WebSocket message:', message);

      switch (message.type) {
        case 'room_participants_update':
          setRoomParticipants(prevMap => {
            const newMap = new Map(prevMap);
            newMap.set(message.data.roomId, message.data.participants);
            return newMap;
          });
          break;
        
        case 'knock_request':
          setKnockRequests(prev => [...prev, message.data]);
          break;
        
        case 'knock_response':
          // Handle knock response
          if (message.data.accepted && activeRoomId !== message.data.roomId) {
            // Join the room if knock was accepted
            joinRoom(message.data.roomId);
          }
          break;
        
        case 'notifications_update':
          setNotifications(message.data.notifications);
          break;
        
        case 'room_message':
          setRoomMessages(prevMap => {
            const newMap = new Map(prevMap);
            const roomId = message.data.roomId;
            const currentMessages = newMap.get(roomId) || [];
            newMap.set(roomId, [...currentMessages, message.data]);
            return newMap;
          });
          break;
        
        case 'user_status_update':
          setOnlineUsers(prevMap => {
            const newMap = new Map(prevMap);
            newMap.set(message.data.id, {
              status: message.data.status,
              displayName: message.data.displayName
            });
            return newMap;
          });
          break;
      }
    };

    setSocket(newSocket);

    return () => {
      newSocket.close();
    };
  }, [activeRoomId]);

  const sendMessage = useCallback((type: string, data: any) => {
    if (socket && connected) {
      socket.send(JSON.stringify({
        type,
        data
      }));
    }
  }, [socket, connected]);

  const joinRoom = useCallback((roomId: number) => {
    setActiveRoomId(roomId);
    sendMessage('join_room', { roomId });
  }, [sendMessage]);

  const leaveRoom = useCallback(() => {
    if (activeRoomId) {
      sendMessage('leave_room', { roomId: activeRoomId });
      setActiveRoomId(null);
    }
  }, [activeRoomId, sendMessage]);

  const knockOnDoor = useCallback((roomId: number) => {
    sendMessage('knock_on_door', { roomId });
  }, [sendMessage]);

  const respondToKnock = useCallback((knockId: number, accepted: boolean) => {
    sendMessage('respond_to_knock', { knockId, accepted });
    
    // Remove the knock request from the list
    setKnockRequests(prev => prev.filter(kr => kr.id !== knockId));
  }, [sendMessage]);
  
  const sendRoomMessage = useCallback((message: string) => {
    if (activeRoomId) {
      sendMessage('room_message', { roomId: activeRoomId, message });
    }
  }, [activeRoomId, sendMessage]);

  const value = {
    connected,
    sendMessage,
    roomParticipants,
    activeRoomId,
    joinRoom,
    leaveRoom,
    knockOnDoor,
    respondToKnock,
    knockRequests,
    notifications,
    sendRoomMessage,
    roomMessages,
    onlineUsers,
    connectWebSocket
  };

  return (
    <WebSocketContext.Provider value={value}>
      {children}
    </WebSocketContext.Provider>
  );
}

export function useWebSocket() {
  const context = useContext(WebSocketContext);
  if (!context) {
    throw new Error('useWebSocket must be used within a WebsocketProvider');
  }
  return context;
}
