import { Route, Switch } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { AuthProvider } from "@/hooks/use-auth";
import { WebsocketProvider } from "@/lib/websocket";
import { useEffect } from "react";
import { AIAssistant } from "@/components/chat/ai-assistant";

// Pages
import AuthPage from "@/pages/auth-page";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import MyOffice from "@/pages/my-office";
import Rooms from "@/pages/rooms";
import Tasks from "@/pages/tasks";
import BreakRoom from "@/pages/break-room";
import { ProtectedRoute } from "@/lib/protected-route";

function App() {
  // Check for dark mode preference
  useEffect(() => {
    const isDarkMode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    // Listen for changes in color scheme preference
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = (e: MediaQueryListEvent) => {
      if (e.matches) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    };

    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <WebsocketProvider>
          <div className="flex flex-col min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
            <main className="flex-1">
              <Switch>
                <Route path="/auth" component={AuthPage} />
                <ProtectedRoute path="/" component={Dashboard} />
                <ProtectedRoute path="/my-office" component={MyOffice} />
                <ProtectedRoute path="/rooms" component={Rooms} />
                <ProtectedRoute path="/tasks" component={Tasks} />
                <ProtectedRoute path="/break-room" component={BreakRoom} />
                <Route component={NotFound} />
              </Switch>
            </main>
            <AIAssistant />
            <Toaster />
          </div>
        </WebsocketProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
