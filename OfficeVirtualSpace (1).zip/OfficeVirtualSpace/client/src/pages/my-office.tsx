import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { useWebSocket } from "@/lib/websocket";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function MyOffice() {
  const { user } = useAuth();
  const { onlineUsers, roomParticipants, activeRoomId } = useWebSocket();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("office");
  const [officeBackground, setOfficeBackground] = useState(user?.backgroundUrl || "");

  // Fetch room information if it exists
  const { data: myRoom } = useQuery({
    queryKey: ["/api/rooms/personal"],
    enabled: !!user,
  });

  // Fetch knock requests for my office
  const { data: knockRequests = [] } = useQuery({
    queryKey: ["/api/knocks/room", myRoom?.id],
    enabled: !!myRoom?.id,
  });

  // Update profile/office mutation
  const updateMutation = useMutation({
    mutationFn: async (formData: any) => {
      const res = await apiRequest("PATCH", "/api/users/profile", formData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Office Updated",
        description: "Your office settings have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Respond to knock request mutation
  const respondToKnockMutation = useMutation({
    mutationFn: async ({ knockId, accepted }: { knockId: number; accepted: boolean }) => {
      const res = await apiRequest("POST", `/api/knocks/${knockId}/respond`, { accepted });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/knocks/room", myRoom?.id] });
    },
    onError: (error) => {
      toast({
        title: "Failed to respond to knock",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Save office settings
  const handleSaveSettings = () => {
    updateMutation.mutate({
      backgroundUrl: officeBackground,
    });
  };

  // Handle knock response
  const handleKnockResponse = (knockId: number, accepted: boolean) => {
    respondToKnockMutation.mutate({ knockId, accepted });
  };

  // Get visitors in your office
  const visitors = Array.from((roomParticipants.get(myRoom?.id || 0) || [])).filter(
    (participant) => participant.userId !== user?.id
  );

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">My Office</h1>
            <p className="text-gray-600 dark:text-gray-300">Customize and manage your personal workspace</p>
          </div>
          <div className="mt-4 md:mt-0">
            <Button disabled={!myRoom}>
              {activeRoomId === myRoom?.id ? "You are in your office" : "Enter Office"}
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full md:w-auto grid-cols-3">
            <TabsTrigger value="office">Office View</TabsTrigger>
            <TabsTrigger value="customize">Customize</TabsTrigger>
            <TabsTrigger value="visitors">
              Visitors
              {knockRequests.length > 0 && (
                <span className="ml-2 bg-primary text-white text-xs px-2 py-0.5 rounded-full">
                  {knockRequests.length}
                </span>
              )}
            </TabsTrigger>
          </TabsList>

          {/* Office View Tab */}
          <TabsContent value="office" className="mt-4">
            <Card className="border-0 shadow-none overflow-hidden bg-transparent">
              <div 
                className="bg-cover bg-center rounded-lg aspect-video relative" 
                style={{ 
                  backgroundImage: officeBackground 
                    ? `url('${officeBackground}')`
                    : "linear-gradient(to right, #4f46e5, #7c3aed)" 
                }}
              >
                <div className="absolute inset-0 bg-black/10 p-6 flex flex-col justify-between">
                  <div className="flex justify-between">
                    <div className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-lg p-3 shadow-lg">
                      <h3 className="font-medium text-gray-800 dark:text-white">{user?.displayName}'s Office</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-300">Personal workspace</p>
                    </div>
                    
                    {visitors.length > 0 && (
                      <div className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-lg p-3 shadow-lg">
                        <h3 className="font-medium text-gray-800 dark:text-white">Current Visitors</h3>
                        <div className="flex -space-x-2 mt-1">
                          {visitors.slice(0, 3).map((visitor, i) => (
                            <div key={i} className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white ring-2 ring-white dark:ring-gray-700">
                              {visitor.displayName?.charAt(0) || "V"}
                            </div>
                          ))}
                          {visitors.length > 3 && (
                            <div className="h-8 w-8 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center text-gray-600 dark:text-gray-200 ring-2 ring-white dark:ring-gray-700">
                              +{visitors.length - 3}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-lg p-4 shadow-lg">
                      <h3 className="font-medium mb-2 text-gray-800 dark:text-white">Recent Activity</h3>
                      <div className="space-y-2">
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          {visitors.length > 0 
                            ? `${visitors.length} colleagues in your office now` 
                            : "No colleagues in your office right now"}
                        </p>
                        {knockRequests.length > 0 && (
                          <p className="text-sm text-gray-600 dark:text-gray-300">
                            {knockRequests.length} people waiting to enter
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm rounded-lg p-4 shadow-lg">
                      <h3 className="font-medium mb-2 text-gray-800 dark:text-white">Office Status</h3>
                      <div className="flex items-center">
                        <div className="h-3 w-3 rounded-full bg-green-500 mr-2"></div>
                        <span className="text-sm text-gray-800 dark:text-gray-200">Open for visitors</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Customize Tab */}
          <TabsContent value="customize" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Customize Your Office</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="background">Background Image URL</Label>
                  <Input 
                    id="background" 
                    placeholder="Enter an image URL for your office background" 
                    value={officeBackground || ""}
                    onChange={(e) => setOfficeBackground(e.target.value)}
                  />
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Use a URL of an image you'd like to use as your office background
                  </p>
                </div>

                {/* Background presets */}
                <div>
                  <Label>Background Presets</Label>
                  <div className="grid grid-cols-3 gap-3 mt-2">
                    <button 
                      className="aspect-video rounded-md overflow-hidden border-2 border-transparent hover:border-primary focus:border-primary focus:outline-none"
                      onClick={() => setOfficeBackground("https://images.unsplash.com/photo-1497366754035-f200968a6e72")}
                    >
                      <img 
                        src="https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=200&h=120&auto=format&fit=crop"
                        alt="Modern office" 
                        className="w-full h-full object-cover"
                      />
                    </button>
                    <button 
                      className="aspect-video rounded-md overflow-hidden border-2 border-transparent hover:border-primary focus:border-primary focus:outline-none"
                      onClick={() => setOfficeBackground("https://images.unsplash.com/photo-1497215728101-856f4ea42174")}
                    >
                      <img 
                        src="https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=200&h=120&auto=format&fit=crop"
                        alt="Bright office" 
                        className="w-full h-full object-cover"
                      />
                    </button>
                    <button 
                      className="aspect-video rounded-md overflow-hidden border-2 border-transparent hover:border-primary focus:border-primary focus:outline-none"
                      onClick={() => setOfficeBackground("https://images.unsplash.com/photo-1593062096033-9a26b09da705")}
                    >
                      <img 
                        src="https://images.unsplash.com/photo-1593062096033-9a26b09da705?w=200&h=120&auto=format&fit=crop"
                        alt="Home office" 
                        className="w-full h-full object-cover"
                      />
                    </button>
                  </div>
                </div>

                <Button onClick={handleSaveSettings} disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Visitors Tab */}
          <TabsContent value="visitors" className="mt-4">
            <div className="grid gap-6 grid-cols-1 md:grid-cols-2">
              {/* Current Visitors */}
              <Card>
                <CardHeader>
                  <CardTitle>Current Visitors</CardTitle>
                </CardHeader>
                <CardContent>
                  {visitors.length > 0 ? (
                    <ul className="space-y-3">
                      {visitors.map((visitor, i) => (
                        <li key={i} className="flex items-center gap-3 p-3 bg-gray-50 rounded-md">
                          <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-white">
                            {visitor.displayName?.charAt(0) || "V"}
                          </div>
                          <div>
                            <p className="font-medium">{visitor.displayName}</p>
                            <p className="text-sm text-gray-500">Entered at 10:30 AM</p>
                          </div>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-gray-500">No visitors in your office right now</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Knock Requests */}
              <Card>
                <CardHeader>
                  <CardTitle>Knock Requests</CardTitle>
                </CardHeader>
                <CardContent>
                  {knockRequests.length > 0 ? (
                    <ul className="space-y-3">
                      {knockRequests.map((knock) => (
                        <li key={knock.id} className="p-3 bg-gray-50 rounded-md">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-white">
                              {knock.fromUser?.displayName?.charAt(0) || "U"}
                            </div>
                            <div>
                              <p className="font-medium">{knock.fromUser?.displayName} wants to enter</p>
                              <p className="text-xs text-gray-500">
                                {new Date(knock.createdAt).toLocaleTimeString()}
                              </p>
                            </div>
                          </div>
                          <div className="flex gap-2 mt-2">
                            <Button 
                              size="sm" 
                              onClick={() => handleKnockResponse(knock.id, true)}
                              disabled={respondToKnockMutation.isPending}
                            >
                              Accept
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => handleKnockResponse(knock.id, false)}
                              disabled={respondToKnockMutation.isPending}
                            >
                              Decline
                            </Button>
                          </div>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-gray-500">No pending knock requests</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}