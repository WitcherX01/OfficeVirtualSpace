import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

// Icons
import { 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  Plus, 
  Calendar,
  CheckSquare,
  Square,
  ChevronDown,
  Trash2,
  Edit
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from "@/components/ui/popover";
import { format } from "date-fns";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";

// Task creation/edit schema
const taskSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().optional(),
  priority: z.enum(["low", "medium", "high"]),
  assignedToId: z.number(),
  dueDate: z.date().optional().nullable(),
});

export default function Tasks() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isCreatingTask, setIsCreatingTask] = useState(false);
  const [editingTask, setEditingTask] = useState<any>(null);
  const [activeTab, setActiveTab] = useState("all");

  // Task form
  const form = useForm<z.infer<typeof taskSchema>>({
    resolver: zodResolver(taskSchema),
    defaultValues: {
      title: "",
      description: "",
      priority: "medium",
      assignedToId: user?.id || 0,
      dueDate: null,
    },
  });

  // Fetch users for assigning tasks
  const { data: users = [] } = useQuery({
    queryKey: ["/api/users"],
    enabled: !!user,
  });

  // Fetch tasks
  const { data: tasks = [], isLoading } = useQuery({
    queryKey: ["/api/tasks"],
    enabled: !!user,
  });

  // Create task mutation
  const createTaskMutation = useMutation({
    mutationFn: async (data: z.infer<typeof taskSchema>) => {
      const res = await apiRequest("POST", "/api/tasks", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Task Created",
        description: "Your task has been created successfully.",
      });
      setIsCreatingTask(false);
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to create task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update task mutation
  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const res = await apiRequest("PATCH", `/api/tasks/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Task Updated",
        description: "Task has been updated successfully.",
      });
      setEditingTask(null);
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete task mutation
  const deleteTaskMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/tasks/${id}`);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Task Deleted",
        description: "Task has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle task creation form submission
  const onSubmit = (data: z.infer<typeof taskSchema>) => {
    if (editingTask) {
      updateTaskMutation.mutate({ id: editingTask.id, data });
    } else {
      createTaskMutation.mutate(data);
    }
  };

  // Open edit task dialog
  const handleEditTask = (task: any) => {
    setEditingTask(task);
    form.reset({
      title: task.title,
      description: task.description || "",
      priority: task.priority,
      assignedToId: task.assignedToId,
      dueDate: task.dueDate ? new Date(task.dueDate) : null,
    });
  };

  // Handle task status update
  const handleTaskStatusUpdate = (taskId: number, status: string) => {
    updateTaskMutation.mutate({ 
      id: taskId, 
      data: { status } 
    });
  };

  // Handle task delete
  const handleDeleteTask = (taskId: number) => {
    deleteTaskMutation.mutate(taskId);
  };

  // Reset and close form
  const handleCancelForm = () => {
    form.reset();
    setIsCreatingTask(false);
    setEditingTask(null);
  };

  // Filter tasks based on tab
  const filteredTasks = tasks.filter((task: any) => {
    if (activeTab === "all") return true;
    if (activeTab === "mine") return task.assignedToId === user?.id;
    if (activeTab === "assigned") return task.assignedById === user?.id;
    if (activeTab === "pending") return task.status === "pending";
    if (activeTab === "in-progress") return task.status === "in-progress";
    if (activeTab === "completed") return task.status === "completed";
    return true;
  });

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Tasks</h1>
            <p className="text-gray-600">Manage and track your tasks</p>
          </div>
          <div className="mt-4 md:mt-0">
            <Button onClick={() => setIsCreatingTask(true)}>
              <Plus className="mr-2 h-4 w-4" /> Create Task
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-6 w-full md:w-auto">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="mine">Assigned to Me</TabsTrigger>
            <TabsTrigger value="assigned">Created by Me</TabsTrigger>
            <TabsTrigger value="pending">Pending</TabsTrigger>
            <TabsTrigger value="in-progress">In Progress</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-4">
            {isLoading ? (
              <div className="text-center py-20">
                <p className="text-gray-500">Loading tasks...</p>
              </div>
            ) : filteredTasks.length > 0 ? (
              <div className="grid gap-4">
                {filteredTasks.map((task: any) => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    users={users}
                    currentUserId={user?.id}
                    onStatusChange={handleTaskStatusUpdate}
                    onEdit={handleEditTask}
                    onDelete={handleDeleteTask}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-20">
                <p className="text-gray-500">No tasks found</p>
                <Button variant="outline" className="mt-4" onClick={() => setIsCreatingTask(true)}>
                  Create a Task
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Create/Edit Task Dialog */}
      <Dialog open={isCreatingTask || !!editingTask} onOpenChange={(open) => {
        if (!open) handleCancelForm();
        else setIsCreatingTask(open);
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingTask ? "Edit Task" : "Create a New Task"}</DialogTitle>
            <DialogDescription>
              {editingTask 
                ? "Update the details of your task." 
                : "Add details for the new task and assign it to a team member."
              }
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter task title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter task description" 
                        {...field} 
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="priority"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Priority</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select priority" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="assignedToId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Assign To</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(parseInt(value))} 
                        defaultValue={field.value.toString()}
                        value={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select team member" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {users.map((user: any) => (
                            <SelectItem key={user.id} value={user.id.toString()}>
                              {user.displayName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Due Date (Optional)</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={`w-full pl-3 text-left font-normal ${!field.value ? "text-muted-foreground" : ""}`}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <Calendar className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <CalendarComponent
                          mode="single"
                          selected={field.value || undefined}
                          onSelect={field.onChange}
                          initialFocus
                          disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter className="mt-6">
                <Button type="button" variant="outline" onClick={handleCancelForm}>
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={createTaskMutation.isPending || updateTaskMutation.isPending}
                >
                  {createTaskMutation.isPending || updateTaskMutation.isPending
                    ? "Saving..."
                    : editingTask ? "Update Task" : "Create Task"
                  }
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}

interface TaskCardProps {
  task: any;
  users: any[];
  currentUserId: number;
  onStatusChange: (taskId: number, status: string) => void;
  onEdit: (task: any) => void;
  onDelete: (taskId: number) => void;
}

function TaskCard({ task, users, currentUserId, onStatusChange, onEdit, onDelete }: TaskCardProps) {
  const isAssignedToMe = task.assignedToId === currentUserId;
  const assignee = users.find((user) => user.id === task.assignedToId);
  const creator = users.find((user) => user.id === task.assignedById);

  // Get status icon and color
  const getStatusDisplay = () => {
    switch(task.status) {
      case "completed":
        return { 
          icon: <CheckCircle className="h-5 w-5" />, 
          color: "bg-green-100 text-green-600",
          label: "Completed" 
        };
      case "in-progress":
        return { 
          icon: <Clock className="h-5 w-5" />, 
          color: "bg-blue-100 text-blue-600",
          label: "In Progress" 
        };
      default:
        return { 
          icon: <AlertCircle className="h-5 w-5" />, 
          color: "bg-gray-100 text-gray-600",
          label: "Pending" 
        };
    }
  };

  // Get priority display
  const getPriorityDisplay = () => {
    switch(task.priority) {
      case "high":
        return { color: "text-red-500", label: "High" };
      case "medium":
        return { color: "text-yellow-500", label: "Medium" };
      default:
        return { color: "text-green-500", label: "Low" };
    }
  };

  const statusDisplay = getStatusDisplay();
  const priorityDisplay = getPriorityDisplay();

  // Calculate due date display
  const getDueDateDisplay = () => {
    if (!task.dueDate) return null;
    
    const dueDate = new Date(task.dueDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const isOverdue = task.status !== "completed" && dueDate < today;
    const isToday = dueDate.toDateString() === today.toDateString();
    
    return {
      date: format(dueDate, "PPP"),
      isOverdue,
      isToday,
      color: isOverdue ? "text-red-500" : isToday ? "text-orange-500" : "text-gray-500"
    };
  };

  const dueDateDisplay = getDueDateDisplay();

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="flex items-start gap-3">
            <div 
              className={`mt-1 p-1 rounded-md ${statusDisplay.color}`}
              onClick={() => isAssignedToMe && onStatusChange(task.id, task.status === "completed" ? "pending" : "completed")}
              role="button"
              tabIndex={0}
            >
              {task.status === "completed" ? 
                <CheckSquare className="h-5 w-5" /> : 
                <Square className="h-5 w-5" />
              }
            </div>
            <div>
              <CardTitle className={`text-lg ${task.status === "completed" ? "line-through text-gray-400" : ""}`}>
                {task.title}
              </CardTitle>
              {task.description && (
                <p className="text-sm text-gray-500 mt-1">{task.description}</p>
              )}
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onEdit(task)}>
                <Edit className="h-4 w-4 mr-2" />
                Edit
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onDelete(task.id)}>
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-3">
          {/* Status & Priority */}
          <div className="flex flex-col">
            <span className="text-xs text-gray-500 mb-1">Status</span>
            <div className="flex items-center gap-1">
              {!isAssignedToMe ? (
                <div className={`px-2 py-1 rounded-full text-xs ${statusDisplay.color}`}>
                  {statusDisplay.label}
                </div>
              ) : (
                <Select 
                  onValueChange={(value) => onStatusChange(task.id, value)}
                  defaultValue={task.status}
                >
                  <SelectTrigger className="h-8">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>

          {/* Due Date */}
          <div className="flex flex-col">
            <span className="text-xs text-gray-500 mb-1">Due</span>
            {dueDateDisplay ? (
              <div className={`flex items-center text-sm ${dueDateDisplay.color}`}>
                <Calendar className="h-3 w-3 mr-1" />
                <span>{dueDateDisplay.date}</span>
                {dueDateDisplay.isOverdue && <span className="ml-1">(Overdue)</span>}
                {dueDateDisplay.isToday && <span className="ml-1">(Today)</span>}
              </div>
            ) : (
              <span className="text-sm text-gray-400">No due date</span>
            )}
          </div>

          {/* Assignee */}
          <div className="flex flex-col">
            <span className="text-xs text-gray-500 mb-1">Assigned To</span>
            <div className="flex items-center gap-2">
              <div className="h-6 w-6 rounded-full bg-primary flex items-center justify-center text-white text-xs">
                {assignee?.displayName?.charAt(0) || "U"}
              </div>
              <span className="text-sm truncate">{assignee?.displayName || "Unknown"}</span>
            </div>
          </div>
        </div>

        {/* Additional Info */}
        <div className="flex justify-between mt-4 text-xs text-gray-500">
          <div className="flex items-center gap-1">
            <span className={`font-medium ${priorityDisplay.color}`}>
              {priorityDisplay.label} Priority
            </span>
          </div>
          <div>
            Created by {creator?.displayName || "Unknown"}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}