import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { useWebSocket } from "@/lib/websocket";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

// Icons
import { Users, User, Coffee, Video, Lock, Unlock, Plus } from "lucide-react";

// Room creation schema
const createRoomSchema = z.object({
  name: z.string().min(3, "Room name must be at least 3 characters"),
  type: z.enum(["meeting", "collaboration", "social"]),
  description: z.string().optional(),
  isLocked: z.boolean().default(false),
});

export default function Rooms() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { joinRoom, knockOnDoor, activeRoomId, roomParticipants } = useWebSocket();
  const [activeTab, setActiveTab] = useState("all");
  const [isCreatingRoom, setIsCreatingRoom] = useState(false);

  // Create room form
  const form = useForm<z.infer<typeof createRoomSchema>>({
    resolver: zodResolver(createRoomSchema),
    defaultValues: {
      name: "",
      type: "collaboration",
      description: "",
      isLocked: false,
    },
  });

  // Fetch all rooms
  const { data: rooms = [], isLoading } = useQuery({
    queryKey: ["/api/rooms"],
    enabled: !!user,
  });

  // Create room mutation
  const createRoomMutation = useMutation({
    mutationFn: async (data: z.infer<typeof createRoomSchema>) => {
      const res = await apiRequest("POST", "/api/rooms", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Room Created",
        description: "Your room has been created successfully.",
      });
      setIsCreatingRoom(false);
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/rooms"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to create room",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle room creation form submission
  const onSubmit = (data: z.infer<typeof createRoomSchema>) => {
    createRoomMutation.mutate(data);
  };

  // Handle join/knock on room
  const handleRoomAction = (roomId: number, isLocked: boolean) => {
    if (isLocked) {
      knockOnDoor(roomId);
      toast({
        title: "Knock Sent",
        description: "Your request to enter has been sent to the room owner.",
      });
    } else {
      joinRoom(roomId);
    }
  };

  // Filter rooms based on the active tab
  const filteredRooms = rooms.filter((room: any) => {
    if (activeTab === "all") return true;
    if (activeTab === "meeting") return room.type === "meeting";
    if (activeTab === "collaboration") return room.type === "collaboration";
    if (activeTab === "social") return room.type === "social";
    if (activeTab === "my") return room.ownerId === user?.id;
    return true;
  });

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Rooms</h1>
            <p className="text-gray-600">Join different rooms to collaborate with your team</p>
          </div>
          <div className="mt-4 md:mt-0">
            <Button onClick={() => setIsCreatingRoom(true)}>
              <Plus className="mr-2 h-4 w-4" /> Create Room
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-5 w-full md:w-auto">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="meeting">Meeting</TabsTrigger>
            <TabsTrigger value="collaboration">Collaboration</TabsTrigger>
            <TabsTrigger value="social">Social</TabsTrigger>
            <TabsTrigger value="my">My Rooms</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-4">
            {isLoading ? (
              <div className="text-center py-20">
                <p className="text-gray-500">Loading rooms...</p>
              </div>
            ) : filteredRooms.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredRooms.map((room: any) => (
                  <RoomCard
                    key={room.id}
                    room={room}
                    currentUserId={user?.id}
                    activeRoomId={activeRoomId}
                    participants={roomParticipants.get(room.id) || []}
                    onAction={handleRoomAction}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-20">
                <p className="text-gray-500">No rooms found</p>
                <Button variant="outline" className="mt-4" onClick={() => setIsCreatingRoom(true)}>
                  Create a Room
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Create Room Dialog */}
      <Dialog open={isCreatingRoom} onOpenChange={setIsCreatingRoom}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create a New Room</DialogTitle>
            <DialogDescription>
              Set up a new room for meetings, collaboration, or social interactions.
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Room Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter room name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Room Type</FormLabel>
                    <div className="grid grid-cols-3 gap-2">
                      <Button
                        type="button"
                        variant={field.value === "meeting" ? "default" : "outline"}
                        className="flex flex-col items-center justify-center h-20 p-2"
                        onClick={() => form.setValue("type", "meeting")}
                      >
                        <Video className="h-6 w-6 mb-1" />
                        <span className="text-xs">Meeting</span>
                      </Button>
                      
                      <Button
                        type="button"
                        variant={field.value === "collaboration" ? "default" : "outline"}
                        className="flex flex-col items-center justify-center h-20 p-2"
                        onClick={() => form.setValue("type", "collaboration")}
                      >
                        <Users className="h-6 w-6 mb-1" />
                        <span className="text-xs">Collaboration</span>
                      </Button>
                      
                      <Button
                        type="button"
                        variant={field.value === "social" ? "default" : "outline"}
                        className="flex flex-col items-center justify-center h-20 p-2"
                        onClick={() => form.setValue("type", "social")}
                      >
                        <Coffee className="h-6 w-6 mb-1" />
                        <span className="text-xs">Social</span>
                      </Button>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter room description" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="isLocked"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                    <div className="space-y-0.5">
                      <FormLabel>Private Room</FormLabel>
                      <p className="text-sm text-gray-500">
                        Require approval to join this room
                      </p>
                    </div>
                    <FormControl>
                      <div className="flex items-center h-8">
                        <div 
                          className={`w-11 h-6 rounded-full relative ${field.value ? 'bg-primary' : 'bg-gray-300'} transition-colors`}
                          onClick={() => form.setValue("isLocked", !field.value)}
                        >
                          <div 
                            className={`absolute w-5 h-5 rounded-full bg-white shadow transform transition-transform ${field.value ? 'translate-x-5' : 'translate-x-1'} top-0.5`}
                          />
                        </div>
                      </div>
                    </FormControl>
                  </FormItem>
                )}
              />

              <DialogFooter className="mt-6">
                <Button type="button" variant="outline" onClick={() => setIsCreatingRoom(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createRoomMutation.isPending}>
                  {createRoomMutation.isPending ? "Creating..." : "Create Room"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}

interface RoomCardProps {
  room: any;
  currentUserId: number;
  activeRoomId: number | null;
  participants: any[];
  onAction: (roomId: number, isLocked: boolean) => void;
}

function RoomCard({ room, currentUserId, activeRoomId, participants, onAction }: RoomCardProps) {
  const isOwner = room.ownerId === currentUserId;
  const isActive = activeRoomId === room.id;
  const isUserInRoom = participants.some((p) => p.userId === currentUserId);

  // Get room icon based on type
  const getRoomIcon = () => {
    switch(room.type) {
      case "meeting":
        return <Video className="h-5 w-5" />;
      case "collaboration":
        return <Users className="h-5 w-5" />;
      case "social":
        return <Coffee className="h-5 w-5" />;
      default:
        return <Users className="h-5 w-5" />;
    }
  };

  return (
    <Card className={isActive ? "border-primary" : ""}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-md ${
              room.type === "meeting" ? "bg-purple-100 text-purple-600" :
              room.type === "collaboration" ? "bg-blue-100 text-blue-600" :
              "bg-green-100 text-green-600"
            }`}>
              {getRoomIcon()}
            </div>
            <CardTitle className="text-lg">{room.name}</CardTitle>
          </div>
          {room.isLocked ? (
            <Lock className="h-4 w-4 text-gray-500" />
          ) : (
            <Unlock className="h-4 w-4 text-gray-500" />
          )}
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-gray-500 mb-4">{room.description || "No description provided"}</p>
        
        {/* Participants */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-sm font-medium">Participants</h4>
            <span className="text-xs text-gray-500">{participants.length} people</span>
          </div>
          
          {participants.length > 0 ? (
            <div className="flex -space-x-2">
              {participants.slice(0, 5).map((participant, i) => (
                <div key={i} className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white ring-2 ring-white">
                  {participant.displayName?.charAt(0) || "U"}
                </div>
              ))}
              {participants.length > 5 && (
                <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 ring-2 ring-white">
                  +{participants.length - 5}
                </div>
              )}
            </div>
          ) : (
            <p className="text-xs text-gray-500">No one is in this room</p>
          )}
        </div>
      </CardContent>
      <CardFooter className="pt-0">
        {isUserInRoom || isActive ? (
          <Button className="w-full" variant={isActive ? "default" : "outline"} disabled>
            {isActive ? "You are here" : "Already joined"}
          </Button>
        ) : (
          <Button 
            className="w-full" 
            onClick={() => onAction(room.id, room.isLocked && !isOwner)}
          >
            {room.isLocked && !isOwner ? "Knock to Enter" : "Join Room"}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}