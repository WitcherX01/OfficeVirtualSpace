import { useState, useEffect } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TabsContent, Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { useWebSocket } from "@/lib/websocket";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

// Icons
import { Search, Coffee, Timer, MessageSquare, Clock } from "lucide-react";

export default function BreakRoom() {
  const { user } = useAuth();
  const { activeRoomId, joinRoom, sendRoomMessage, roomMessages } = useWebSocket();
  const [message, setMessage] = useState("");
  const [activeTab, setActiveTab] = useState("lounge");
  const [activeGame, setActiveGame] = useState<string | null>(null);
  const [remainingBreakTime, setRemainingBreakTime] = useState<number | null>(null);
  const [isBreakTime, setIsBreakTime] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  // Break room ID (should be fetched from API, using a static value for now)
  const breakRoomId = 101;

  // Check if it's break time (simplified example)
  useEffect(() => {
    const checkBreakTime = () => {
      const now = new Date();
      const hour = now.getHours();
      const minute = now.getMinutes();
      
      // Set break times (12-1pm lunch, 3-3:15pm afternoon break)
      const isLunchBreak = hour === 12;
      const isAfternoonBreak = hour === 15 && minute < 15;
      
      const isInBreakTime = isLunchBreak || isAfternoonBreak;
      setIsBreakTime(true); // Set to true for demo purposes, should be isInBreakTime in production
      
      // Calculate remaining break time for demo
      if (isLunchBreak) {
        const endTime = new Date();
        endTime.setHours(13, 0, 0, 0);
        setRemainingBreakTime(Math.floor((endTime.getTime() - now.getTime()) / 60000));
      } else if (isAfternoonBreak) {
        const endTime = new Date();
        endTime.setHours(15, 15, 0, 0);
        setRemainingBreakTime(Math.floor((endTime.getTime() - now.getTime()) / 60000));
      } else {
        // For demo, show 30 minutes
        setRemainingBreakTime(30);
      }
    };
    
    checkBreakTime();
    const interval = setInterval(checkBreakTime, 60000); // Update every minute
    
    return () => clearInterval(interval);
  }, []);

  // Join break room
  useEffect(() => {
    if (user && breakRoomId && activeRoomId !== breakRoomId) {
      joinRoom(breakRoomId);
    }
  }, [user, breakRoomId, activeRoomId, joinRoom]);
  
  // Handle message sending
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      sendRoomMessage(message);
      setMessage("");
    }
  };

  // Get messages for the break room
  const messages = roomMessages.get(breakRoomId) || [];

  // Game list for the break room
  const games = [
    { id: "8ball", name: "8 Ball Pool", category: "sports", image: "/games/8ball.webp", url: "https://www.crazygames.com/game/8-ball-pool" },
    { id: "2048", name: "2048", category: "puzzle", image: "/games/2048.webp", url: "https://www.crazygames.com/game/2048" },
    { id: "tetris", name: "Tetris", category: "puzzle", image: "/games/tetris.webp", url: "https://www.crazygames.com/game/tetris" },
    { id: "chess", name: "Chess", category: "board", image: "/games/chess.webp", url: "https://www.crazygames.com/game/chess" },
    { id: "sudoku", name: "Sudoku", category: "puzzle", image: "/games/sudoku.webp", url: "https://www.crazygames.com/game/sudoku" },
    { id: "wordle", name: "Wordle", category: "puzzle", image: "/games/wordle.webp", url: "https://www.crazygames.com/game/wordle" },
    { id: "crossword", name: "Crossword", category: "puzzle", image: "/games/crossword.webp", url: "https://www.crazygames.com/game/crossword" },
    { id: "snake", name: "Snake", category: "arcade", image: "/games/snake.webp", url: "https://www.crazygames.com/game/snake" }
  ];

  // Filter games by search term
  const filteredGames = games.filter(game => 
    game.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    game.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Break Room</h1>
            <p className="text-gray-600">Relax, chat, and play games during your break time</p>
          </div>
          <div className="mt-4 md:mt-0 flex items-center gap-2 bg-white px-3 py-1.5 rounded-md border">
            <Coffee className="h-5 w-5 text-primary" />
            <div className="text-sm">
              {isBreakTime ? (
                <span className="text-green-600 font-medium">
                  Break Time: {remainingBreakTime} min left
                </span>
              ) : (
                <span className="text-gray-500">
                  Not Break Time
                </span>
              )}
            </div>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full md:w-auto grid-cols-2">
            <TabsTrigger value="lounge">
              <MessageSquare className="h-4 w-4 mr-2" />
              Chat Lounge
            </TabsTrigger>
            <TabsTrigger value="games">
              <Coffee className="h-4 w-4 mr-2" />
              Games
            </TabsTrigger>
          </TabsList>

          {/* Chat Lounge */}
          <TabsContent value="lounge" className="mt-4">
            <div className="grid grid-cols-1 gap-6">
              <Card className="col-span-1">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Break Room Chat</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Chat Messages */}
                  <ScrollArea className="h-[400px] p-4 rounded-md border">
                    {messages.length > 0 ? (
                      <div className="space-y-4">
                        {messages.map((msg, idx) => (
                          <div
                            key={idx}
                            className={`flex gap-2 ${
                              msg.userId === user?.id
                                ? "justify-end"
                                : "justify-start"
                            }`}
                          >
                            <div
                              className={`max-w-[80%] rounded-lg p-3 ${
                                msg.userId === user?.id
                                  ? "bg-primary text-primary-foreground"
                                  : "bg-muted"
                              }`}
                            >
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium text-xs">
                                  {msg.userId === user?.id
                                    ? "You"
                                    : msg.sender?.displayName}
                                </span>
                                <span className="text-xs opacity-70">
                                  {new Date(msg.timestamp).toLocaleTimeString([], {
                                    hour: "2-digit",
                                    minute: "2-digit",
                                  })}
                                </span>
                              </div>
                              <p>{msg.text}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="h-full flex items-center justify-center text-gray-500">
                        <p>No messages yet. Start the conversation!</p>
                      </div>
                    )}
                  </ScrollArea>

                  {/* Message Input */}
                  <form onSubmit={handleSendMessage} className="flex gap-2">
                    <Input
                      placeholder="Type your message..."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="flex-1"
                    />
                    <Button type="submit">Send</Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Games Tab */}
          <TabsContent value="games" className="mt-4">
            {!isBreakTime && !activeGame ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-10">
                  <Clock className="h-16 w-16 text-gray-300 mb-4" />
                  <h3 className="text-xl font-medium mb-2">Games Available During Break Time</h3>
                  <p className="text-gray-500 text-center max-w-md">
                    Games are only available during your designated break periods to help you relax and recharge.
                  </p>
                </CardContent>
              </Card>
            ) : activeGame ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold">
                    {games.find(g => g.id === activeGame)?.name}
                  </h2>
                  <Button
                    variant="outline" 
                    onClick={() => setActiveGame(null)}
                  >
                    Back to Games
                  </Button>
                </div>
                <div className="bg-gray-100 rounded-lg overflow-hidden aspect-video">
                  <div className="w-full h-full flex items-center justify-center">
                    <p className="text-gray-500">
                      Game iframe would be loaded here from CrazyGames.io
                      <br />
                      <span className="text-sm">
                        (For a real implementation, we would embed the game using an iframe from CrazyGames)
                      </span>
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Search Bar */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
                  <Input
                    className="pl-9"
                    placeholder="Search games..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>

                {/* Games Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {filteredGames.map((game) => (
                    <Card 
                      key={game.id} 
                      className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() => setActiveGame(game.id)}
                    >
                      {/* Game Image */}
                      <div className="aspect-video bg-gray-100 flex items-center justify-center">
                        <Coffee className="h-12 w-12 text-gray-300" />
                      </div>
                      
                      <CardContent className="p-4">
                        <h3 className="font-medium">{game.name}</h3>
                        <p className="text-xs text-gray-500 mt-1 capitalize">{game.category}</p>
                      </CardContent>
                    </Card>
                  ))}

                  {filteredGames.length === 0 && (
                    <div className="col-span-full text-center py-10">
                      <p className="text-gray-500">No games found matching "{searchTerm}"</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}