import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useWebSocket } from "@/lib/websocket";

import { Users, CheckSquare, Calendar, BarChart2 } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  const { connectWebSocket } = useWebSocket();

  // Connect to WebSocket when user is available
  useEffect(() => {
    if (user) {
      connectWebSocket(user.id);
    }
  }, [user, connectWebSocket]);

  // Fetch user tasks
  const { data: tasks = [] } = useQuery({
    queryKey: ["/api/tasks/user"],
    enabled: !!user,
  });

  // Fetch upcoming meetings
  const { data: meetings = [] } = useQuery({
    queryKey: ["/api/meetings/upcoming"],
    enabled: !!user,
  });

  // Fetch available rooms
  const { data: rooms = [] } = useQuery({
    queryKey: ["/api/rooms"],
    enabled: !!user,
  });

  // Fetch notifications
  const { data: notifications = [] } = useQuery({
    queryKey: ["/api/notifications"],
    enabled: !!user,
  });

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Welcome Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h1 className="text-2xl font-bold text-gray-800">Welcome back, {user?.displayName}</h1>
          <p className="text-gray-600 mt-1">Here's an overview of your workspace today</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard 
            title="Active Rooms"
            value={rooms.length}
            icon={<Users className="h-5 w-5" />}
            color="bg-blue-500"
          />
          <StatsCard 
            title="Tasks"
            value={tasks.filter(t => t.status === 'in-progress').length}
            icon={<CheckSquare className="h-5 w-5" />}
            color="bg-green-500"
          />
          <StatsCard 
            title="Meetings"
            value={meetings.length}
            icon={<Calendar className="h-5 w-5" />}
            color="bg-purple-500"
          />
          <StatsCard 
            title="Productivity"
            value="85%"
            icon={<BarChart2 className="h-5 w-5" />}
            color="bg-orange-500"
          />
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Tasks Card */}
          <Card>
            <CardHeader>
              <CardTitle>Tasks</CardTitle>
              <CardDescription>Your active tasks</CardDescription>
            </CardHeader>
            <CardContent>
              {tasks.length > 0 ? (
                <ul className="space-y-3">
                  {tasks.slice(0, 5).map((task) => (
                    <li key={task.id} className="bg-gray-50 p-3 rounded-md">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-medium text-gray-800">{task.title}</h4>
                          <p className="text-sm text-gray-500 mt-1">{task.description}</p>
                        </div>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          task.status === 'completed' ? 'bg-green-100 text-green-800' :
                          task.status === 'in-progress' ? 'bg-blue-100 text-blue-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {task.status}
                        </span>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="text-center py-6">
                  <p className="text-gray-500">No tasks assigned to you</p>
                  <button className="mt-2 text-sm text-primary">Create a task</button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Meetings Card */}
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Meetings</CardTitle>
              <CardDescription>Your scheduled meetings</CardDescription>
            </CardHeader>
            <CardContent>
              {meetings.length > 0 ? (
                <ul className="space-y-3">
                  {meetings.slice(0, 3).map((meeting) => (
                    <li key={meeting.id} className="bg-gray-50 p-3 rounded-md">
                      <h4 className="font-medium text-gray-800">{meeting.title}</h4>
                      <div className="mt-2 flex justify-between text-sm">
                        <span className="text-gray-500">
                          {new Date(meeting.startTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </span>
                        <button className="text-primary">Join</button>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="text-center py-6">
                  <p className="text-gray-500">No upcoming meetings</p>
                  <button className="mt-2 text-sm text-primary">Schedule a meeting</button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Notifications Card */}
          <Card>
            <CardHeader>
              <CardTitle>Notifications</CardTitle>
              <CardDescription>Recent updates</CardDescription>
            </CardHeader>
            <CardContent>
              {notifications.length > 0 ? (
                <ul className="space-y-3">
                  {notifications.slice(0, 5).map((notification) => (
                    <li key={notification.id} className="bg-gray-50 p-3 rounded-md">
                      <p className="text-sm text-gray-700">{notification.message}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(notification.createdAt).toLocaleString()}
                      </p>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="text-center py-6">
                  <p className="text-gray-500">No new notifications</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
}

function StatsCard({ title, value, icon, color }: StatsCardProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">{title}</p>
            <h3 className="text-2xl font-bold mt-1">{value}</h3>
          </div>
          <div className={`p-3 rounded-full ${color} text-white`}>
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}