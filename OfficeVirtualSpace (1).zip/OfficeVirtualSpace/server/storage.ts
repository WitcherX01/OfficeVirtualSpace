import { users, tasks, rooms, knockRequests, meetings, notifications, roomParticipants } from "@shared/schema";
import type { 
  User, InsertUser, 
  Task, InsertTask, 
  Room, InsertRoom, 
  KnockRequest, InsertKnockRequest, 
  Meeting, InsertMeeting, 
  Notification, InsertNotification,
  RoomParticipant, InsertRoomParticipant
} from "@shared/schema";
import { db } from "./db";
import { and, eq, ne, gte, or, inArray, asc, desc, sql, desc as descending } from "drizzle-orm";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import pkg from 'pg';
const { Pool } = pkg;
import memoryStore from "memorystore";

// Create session stores
const PostgresStore = connectPgSimple(session);
const MemoryStore = memoryStore(session);

// Create a PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  // Task operations
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<Task>): Promise<Task | undefined>;
  getTasksByAssignee(userId: number): Promise<Task[]>;
  getTasksByStatus(userId: number, status: string): Promise<Task[]>;
  
  // Room operations
  getRoom(id: number): Promise<Room | undefined>;
  getRooms(): Promise<Room[]>;
  getUserRooms(userId: number): Promise<Room[]>;
  createRoom(room: InsertRoom): Promise<Room>;
  updateRoom(id: number, room: Partial<Room>): Promise<Room | undefined>;
  
  // Knock request operations
  getKnockRequest(id: number): Promise<KnockRequest | undefined>;
  createKnockRequest(knockRequest: InsertKnockRequest): Promise<KnockRequest>;
  updateKnockRequest(id: number, status: string): Promise<KnockRequest | undefined>;
  getPendingKnockRequestsForRoom(roomId: number): Promise<KnockRequest[]>;
  
  // Meeting operations
  getMeeting(id: number): Promise<Meeting | undefined>;
  createMeeting(meeting: InsertMeeting): Promise<Meeting>;
  updateMeeting(id: number, meeting: Partial<Meeting>): Promise<Meeting | undefined>;
  getUpcomingMeetings(userId: number): Promise<Meeting[]>;
  
  // Notification operations
  getNotification(id: number): Promise<Notification | undefined>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<Notification | undefined>;
  getUserNotifications(userId: number): Promise<Notification[]>;
  
  // Room participants operations
  addUserToRoom(data: InsertRoomParticipant): Promise<RoomParticipant>;
  removeUserFromRoom(userId: number, roomId: number): Promise<void>;
  getRoomParticipants(roomId: number): Promise<RoomParticipant[]>;
  getUsersInRoom(roomId: number): Promise<number[]>;
  
  // Session store for authentication
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresStore({
      pool,
      createTableIfMissing: true,
    });
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result.length > 0 ? result[0] : undefined;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result.length > 0 ? result[0] : undefined;
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const result = await db.update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    
    return result.length > 0 ? result[0] : undefined;
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }
  
  // Task operations
  async getTask(id: number): Promise<Task | undefined> {
    const result = await db.select().from(tasks).where(eq(tasks.id, id));
    return result.length > 0 ? result[0] : undefined;
  }
  
  async createTask(insertTask: InsertTask): Promise<Task> {
    const result = await db.insert(tasks).values(insertTask).returning();
    return result[0];
  }
  
  async updateTask(id: number, taskData: Partial<Task>): Promise<Task | undefined> {
    const result = await db.update(tasks)
      .set(taskData)
      .where(eq(tasks.id, id))
      .returning();
    
    return result.length > 0 ? result[0] : undefined;
  }
  
  async getTasksByAssignee(userId: number): Promise<Task[]> {
    return await db.select().from(tasks).where(eq(tasks.assignedToId, userId));
  }
  
  async getTasksByStatus(userId: number, status: string): Promise<Task[]> {
    return await db.select().from(tasks).where(
      and(
        eq(tasks.assignedToId, userId),
        eq(tasks.status, status)
      )
    );
  }
  
  // Room operations
  async getRoom(id: number): Promise<Room | undefined> {
    const result = await db.select().from(rooms).where(eq(rooms.id, id));
    return result.length > 0 ? result[0] : undefined;
  }
  
  async getRooms(): Promise<Room[]> {
    return await db.select().from(rooms);
  }
  
  async getUserRooms(userId: number): Promise<Room[]> {
    // Get rooms owned by the user
    const ownedRooms = await db.select().from(rooms).where(eq(rooms.ownerId, userId));
    
    // Get IDs of rooms the user is participating in
    const participantRoomIds = await db.select({ roomId: roomParticipants.roomId })
      .from(roomParticipants)
      .where(eq(roomParticipants.userId, userId));
    
    // If no participating rooms, just return owned rooms
    if (participantRoomIds.length === 0) {
      return ownedRooms;
    }
    
    // Otherwise, get non-owned rooms the user is participating in
    const participantRooms = await db.select().from(rooms).where(
      and(
        inArray(rooms.id, participantRoomIds.map(r => r.roomId)),
        ne(rooms.ownerId, userId)
      )
    );
    
    // Combine owned and participating rooms
    return [...ownedRooms, ...participantRooms];
  }
  
  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const result = await db.insert(rooms).values(insertRoom).returning();
    return result[0];
  }
  
  async updateRoom(id: number, roomData: Partial<Room>): Promise<Room | undefined> {
    const result = await db.update(rooms)
      .set(roomData)
      .where(eq(rooms.id, id))
      .returning();
    
    return result.length > 0 ? result[0] : undefined;
  }
  
  // Knock request operations
  async getKnockRequest(id: number): Promise<KnockRequest | undefined> {
    const result = await db.select().from(knockRequests).where(eq(knockRequests.id, id));
    return result.length > 0 ? result[0] : undefined;
  }
  
  async createKnockRequest(insertKnockRequest: InsertKnockRequest): Promise<KnockRequest> {
    const result = await db.insert(knockRequests).values(insertKnockRequest).returning();
    return result[0];
  }
  
  async updateKnockRequest(id: number, status: string): Promise<KnockRequest | undefined> {
    const result = await db.update(knockRequests)
      .set({ status })
      .where(eq(knockRequests.id, id))
      .returning();
    
    return result.length > 0 ? result[0] : undefined;
  }
  
  async getPendingKnockRequestsForRoom(roomId: number): Promise<KnockRequest[]> {
    return await db.select().from(knockRequests).where(
      and(
        eq(knockRequests.toRoomId, roomId),
        eq(knockRequests.status, "pending")
      )
    );
  }
  
  // Meeting operations
  async getMeeting(id: number): Promise<Meeting | undefined> {
    const result = await db.select().from(meetings).where(eq(meetings.id, id));
    return result.length > 0 ? result[0] : undefined;
  }
  
  async createMeeting(insertMeeting: InsertMeeting): Promise<Meeting> {
    const result = await db.insert(meetings).values(insertMeeting).returning();
    return result[0];
  }
  
  async updateMeeting(id: number, meetingData: Partial<Meeting>): Promise<Meeting | undefined> {
    const result = await db.update(meetings)
      .set(meetingData)
      .where(eq(meetings.id, id))
      .returning();
    
    return result.length > 0 ? result[0] : undefined;
  }
  
  async getUpcomingMeetings(userId: number): Promise<Meeting[]> {
    const now = new Date();
    
    return await db.select().from(meetings).where(
      and(
        gte(meetings.startTime, now),
        eq(meetings.createdById, userId)
      )
    ).orderBy(meetings.startTime);
  }
  
  // Notification operations
  async getNotification(id: number): Promise<Notification | undefined> {
    const result = await db.select().from(notifications).where(eq(notifications.id, id));
    return result.length > 0 ? result[0] : undefined;
  }
  
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const result = await db.insert(notifications).values(insertNotification).returning();
    return result[0];
  }
  
  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const result = await db.update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id))
      .returning();
    
    return result.length > 0 ? result[0] : undefined;
  }
  
  async getUserNotifications(userId: number): Promise<Notification[]> {
    return await db.select().from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(descending(notifications.createdAt));
  }
  
  // Room participants operations
  async addUserToRoom(data: InsertRoomParticipant): Promise<RoomParticipant> {
    // First remove user from any other rooms
    await db.delete(roomParticipants).where(eq(roomParticipants.userId, data.userId));
    
    // Then add to the new room
    const result = await db.insert(roomParticipants).values(data).returning();
    return result[0];
  }
  
  async removeUserFromRoom(userId: number, roomId: number): Promise<void> {
    await db.delete(roomParticipants).where(
      and(
        eq(roomParticipants.userId, userId),
        eq(roomParticipants.roomId, roomId)
      )
    );
  }
  
  async getRoomParticipants(roomId: number): Promise<RoomParticipant[]> {
    return await db.select().from(roomParticipants)
      .where(eq(roomParticipants.roomId, roomId));
  }
  
  async getUsersInRoom(roomId: number): Promise<number[]> {
    const participants = await this.getRoomParticipants(roomId);
    return participants.map(p => p.userId);
  }
}

// In-memory storage implementation for development
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tasks: Map<number, Task>;
  private rooms: Map<number, Room>;
  private knockRequests: Map<number, KnockRequest>;
  private meetings: Map<number, Meeting>;
  private notifications: Map<number, Notification>;
  private roomParticipants: Map<number, RoomParticipant>;
  
  sessionStore: session.Store;
  
  private userIdCounter: number;
  private taskIdCounter: number;
  private roomIdCounter: number;
  private knockRequestIdCounter: number;
  private meetingIdCounter: number;
  private notificationIdCounter: number;
  private roomParticipantIdCounter: number;

  constructor() {
    this.users = new Map();
    this.tasks = new Map();
    this.rooms = new Map();
    this.knockRequests = new Map();
    this.meetings = new Map();
    this.notifications = new Map();
    this.roomParticipants = new Map();
    
    this.userIdCounter = 1;
    this.taskIdCounter = 1;
    this.roomIdCounter = 1;
    this.knockRequestIdCounter = 1;
    this.meetingIdCounter = 1;
    this.notificationIdCounter = 1;
    this.roomParticipantIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Clear expired sessions every 24h
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      status: "offline",
      lastLogin: null,
      lastLogout: null
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Task methods
  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }
  
  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.taskIdCounter++;
    const now = new Date();
    const task: Task = { 
      ...insertTask, 
      id,
      createdAt: now
    };
    this.tasks.set(id, task);
    return task;
  }
  
  async updateTask(id: number, taskData: Partial<Task>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    
    const updatedTask = { ...task, ...taskData };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }
  
  async getTasksByAssignee(userId: number): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(
      (task) => task.assignedToId === userId
    );
  }
  
  async getTasksByStatus(userId: number, status: string): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(
      (task) => task.assignedToId === userId && task.status === status
    );
  }

  // Room methods
  async getRoom(id: number): Promise<Room | undefined> {
    return this.rooms.get(id);
  }
  
  async getRooms(): Promise<Room[]> {
    return Array.from(this.rooms.values());
  }
  
  async getUserRooms(userId: number): Promise<Room[]> {
    return Array.from(this.rooms.values()).filter(
      (room) => room.ownerId === userId || room.type !== "personal"
    );
  }
  
  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const id = this.roomIdCounter++;
    const now = new Date();
    const room: Room = { 
      ...insertRoom, 
      id,
      createdAt: now
    };
    this.rooms.set(id, room);
    return room;
  }
  
  async updateRoom(id: number, roomData: Partial<Room>): Promise<Room | undefined> {
    const room = this.rooms.get(id);
    if (!room) return undefined;
    
    const updatedRoom = { ...room, ...roomData };
    this.rooms.set(id, updatedRoom);
    return updatedRoom;
  }

  // Knock request methods
  async getKnockRequest(id: number): Promise<KnockRequest | undefined> {
    return this.knockRequests.get(id);
  }
  
  async createKnockRequest(insertKnockRequest: InsertKnockRequest): Promise<KnockRequest> {
    const id = this.knockRequestIdCounter++;
    const now = new Date();
    const knockRequest: KnockRequest = { 
      ...insertKnockRequest, 
      id,
      status: "pending",
      createdAt: now
    };
    this.knockRequests.set(id, knockRequest);
    return knockRequest;
  }
  
  async updateKnockRequest(id: number, status: string): Promise<KnockRequest | undefined> {
    const knockRequest = this.knockRequests.get(id);
    if (!knockRequest) return undefined;
    
    const updatedKnockRequest = { ...knockRequest, status };
    this.knockRequests.set(id, updatedKnockRequest);
    return updatedKnockRequest;
  }
  
  async getPendingKnockRequestsForRoom(roomId: number): Promise<KnockRequest[]> {
    return Array.from(this.knockRequests.values()).filter(
      (kr) => kr.toRoomId === roomId && kr.status === "pending"
    );
  }

  // Meeting methods
  async getMeeting(id: number): Promise<Meeting | undefined> {
    return this.meetings.get(id);
  }
  
  async createMeeting(insertMeeting: InsertMeeting): Promise<Meeting> {
    const id = this.meetingIdCounter++;
    const meeting: Meeting = { 
      ...insertMeeting, 
      id,
    };
    this.meetings.set(id, meeting);
    return meeting;
  }
  
  async updateMeeting(id: number, meetingData: Partial<Meeting>): Promise<Meeting | undefined> {
    const meeting = this.meetings.get(id);
    if (!meeting) return undefined;
    
    const updatedMeeting = { ...meeting, ...meetingData };
    this.meetings.set(id, updatedMeeting);
    return updatedMeeting;
  }
  
  async getUpcomingMeetings(userId: number): Promise<Meeting[]> {
    const now = new Date();
    const userRooms = await this.getUserRooms(userId);
    const roomIds = userRooms.map(room => room.id);
    
    return Array.from(this.meetings.values()).filter(
      (meeting) => meeting.startTime > now && 
        (meeting.createdById === userId || (meeting.roomId && roomIds.includes(meeting.roomId)))
    )
    .sort((a, b) => a.startTime.getTime() - b.startTime.getTime());
  }

  // Notification methods
  async getNotification(id: number): Promise<Notification | undefined> {
    return this.notifications.get(id);
  }
  
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.notificationIdCounter++;
    const now = new Date();
    const notification: Notification = { 
      ...insertNotification, 
      id,
      isRead: false,
      createdAt: now
    };
    this.notifications.set(id, notification);
    return notification;
  }
  
  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const notification = this.notifications.get(id);
    if (!notification) return undefined;
    
    const updatedNotification = { ...notification, isRead: true };
    this.notifications.set(id, updatedNotification);
    return updatedNotification;
  }
  
  async getUserNotifications(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // Room participants methods
  async addUserToRoom(data: InsertRoomParticipant): Promise<RoomParticipant> {
    // First, remove user from any other rooms
    const participantsToRemove = Array.from(this.roomParticipants.values())
      .filter(p => p.userId === data.userId);
    
    for (const p of participantsToRemove) {
      this.roomParticipants.delete(p.id);
    }
    
    const id = this.roomParticipantIdCounter++;
    const now = new Date();
    const participant: RoomParticipant = {
      ...data,
      id,
      joinedAt: now
    };
    
    this.roomParticipants.set(id, participant);
    return participant;
  }
  
  async removeUserFromRoom(userId: number, roomId: number): Promise<void> {
    const participants = Array.from(this.roomParticipants.values())
      .filter(p => p.userId === userId && p.roomId === roomId);
    
    for (const p of participants) {
      this.roomParticipants.delete(p.id);
    }
  }
  
  async getRoomParticipants(roomId: number): Promise<RoomParticipant[]> {
    return Array.from(this.roomParticipants.values())
      .filter(p => p.roomId === roomId);
  }
  
  async getUsersInRoom(roomId: number): Promise<number[]> {
    const participants = await this.getRoomParticipants(roomId);
    return participants.map(p => p.userId);
  }
}

// Use DatabaseStorage instead of MemStorage
export const storage = new DatabaseStorage();