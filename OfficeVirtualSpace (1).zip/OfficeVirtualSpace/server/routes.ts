import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { insertTaskSchema, insertRoomSchema, insertKnockRequestSchema, insertMeetingSchema } from "@shared/schema";

// WebSocket connections by user ID
const clients = new Map<number, WebSocket>();

interface WebSocketMessage {
  type: string;
  data: any;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Create HTTP server for both Express and WebSocket
  const httpServer = createServer(app);
  
  // Setup WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws, req) => {
    // The user ID will be set when user authenticates
    let userId: number | null = null;
    
    ws.on('message', async (message) => {
      try {
        const msg = JSON.parse(message.toString()) as WebSocketMessage;
        
        switch (msg.type) {
          case 'authenticate': {
            const user = await storage.getUser(msg.data.userId);
            if (user) {
              userId = user.id;
              clients.set(userId, ws);
              
              // Notify user about pending knock requests
              const userRooms = await storage.getUserRooms(userId);
              for (const room of userRooms) {
                if (room.ownerId === userId) {
                  const pendingKnocks = await storage.getPendingKnockRequestsForRoom(room.id);
                  for (const knock of pendingKnocks) {
                    const knocker = await storage.getUser(knock.fromUserId);
                    if (knocker) {
                      ws.send(JSON.stringify({
                        type: 'knock_request',
                        data: {
                          id: knock.id,
                          room: room,
                          user: {
                            id: knocker.id,
                            displayName: knocker.displayName,
                            username: knocker.username,
                            status: knocker.status,
                            avatarUrl: knocker.avatarUrl
                          }
                        }
                      }));
                    }
                  }
                }
              }
              
              // Send user's rooms info
              ws.send(JSON.stringify({
                type: 'rooms_update',
                data: {
                  rooms: await storage.getUserRooms(userId)
                }
              }));
              
              // Send user's notifications
              ws.send(JSON.stringify({
                type: 'notifications_update',
                data: {
                  notifications: await storage.getUserNotifications(userId)
                }
              }));
            }
            break;
          }
          
          case 'update_status': {
            if (userId) {
              const user = await storage.updateUser(userId, { status: msg.data.status });
              if (user) {
                // Broadcast to all connected clients that this user changed status
                broadcastUserStatus(user);
              }
            }
            break;
          }
          
          case 'join_room': {
            if (userId) {
              const roomId = msg.data.roomId;
              const room = await storage.getRoom(roomId);
              
              if (room) {
                // If it's a personal room and user is not the owner, check if they're allowed
                if (room.type === "personal" && room.ownerId !== userId && room.isLocked) {
                  // Check if there's an accepted knock request
                  const knockRequests = await storage.getPendingKnockRequestsForRoom(roomId);
                  const hasAcceptedKnock = knockRequests.some(
                    kr => kr.fromUserId === userId && kr.status === "accepted"
                  );
                  
                  if (!hasAcceptedKnock) {
                    ws.send(JSON.stringify({
                      type: 'error',
                      data: { message: 'Access denied. You need to knock first.' }
                    }));
                    return;
                  }
                }
                
                // Add user to room
                await storage.addUserToRoom({
                  roomId,
                  userId
                });
                
                // Broadcast to everyone in the room that this user joined
                const roomParticipants = await storage.getRoomParticipants(roomId);
                const participants = await Promise.all(
                  roomParticipants.map(async (p) => {
                    const user = await storage.getUser(p.userId);
                    return user ? {
                      id: user.id,
                      displayName: user.displayName,
                      status: user.status,
                      avatarUrl: user.avatarUrl
                    } : null;
                  })
                );
                
                // Filter out null values
                const validParticipants = participants.filter(p => p !== null);
                
                // Send to all participants
                for (const participant of roomParticipants) {
                  const clientWs = clients.get(participant.userId);
                  if (clientWs && clientWs.readyState === WebSocket.OPEN) {
                    clientWs.send(JSON.stringify({
                      type: 'room_participants_update',
                      data: {
                        roomId,
                        participants: validParticipants
                      }
                    }));
                  }
                }
              }
            }
            break;
          }
          
          case 'leave_room': {
            if (userId) {
              const roomId = msg.data.roomId;
              
              // Remove user from room
              await storage.removeUserFromRoom(userId, roomId);
              
              // Broadcast to everyone in the room that this user left
              const roomParticipants = await storage.getRoomParticipants(roomId);
              const participants = await Promise.all(
                roomParticipants.map(async (p) => {
                  const user = await storage.getUser(p.userId);
                  return user ? {
                    id: user.id,
                    displayName: user.displayName,
                    status: user.status,
                    avatarUrl: user.avatarUrl
                  } : null;
                })
              );
              
              // Filter out null values
              const validParticipants = participants.filter(p => p !== null);
              
              // Send to all participants
              for (const participant of roomParticipants) {
                const clientWs = clients.get(participant.userId);
                if (clientWs && clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(JSON.stringify({
                    type: 'room_participants_update',
                    data: {
                      roomId,
                      participants: validParticipants
                    }
                  }));
                }
              }
            }
            break;
          }
          
          case 'knock_on_door': {
            if (userId) {
              const roomId = msg.data.roomId;
              const room = await storage.getRoom(roomId);
              
              if (room && room.ownerId) {
                // Create knock request
                const knockRequest = await storage.createKnockRequest({
                  fromUserId: userId,
                  toRoomId: roomId
                });
                
                // Create notification for room owner
                await storage.createNotification({
                  userId: room.ownerId,
                  type: 'knock',
                  message: `Someone is knocking on your office door`,
                  relatedId: knockRequest.id
                });
                
                // Notify room owner if they're online
                const ownerWs = clients.get(room.ownerId);
                if (ownerWs && ownerWs.readyState === WebSocket.OPEN) {
                  const knocker = await storage.getUser(userId);
                  if (knocker) {
                    ownerWs.send(JSON.stringify({
                      type: 'knock_request',
                      data: {
                        id: knockRequest.id,
                        room: room,
                        user: {
                          id: knocker.id,
                          displayName: knocker.displayName,
                          username: knocker.username,
                          status: knocker.status,
                          avatarUrl: knocker.avatarUrl
                        }
                      }
                    }));
                  }
                }
                
                // Notify user that knock was sent
                ws.send(JSON.stringify({
                  type: 'knock_sent',
                  data: { roomId }
                }));
              }
            }
            break;
          }
          
          case 'respond_to_knock': {
            if (userId) {
              const knockId = msg.data.knockId;
              const accepted = msg.data.accepted;
              
              const knockRequest = await storage.getKnockRequest(knockId);
              if (knockRequest) {
                const room = await storage.getRoom(knockRequest.toRoomId);
                
                // Only room owner can respond to knocks
                if (room && room.ownerId === userId) {
                  const status = accepted ? "accepted" : "rejected";
                  await storage.updateKnockRequest(knockId, status);
                  
                  // Notify the knocker
                  const knockerWs = clients.get(knockRequest.fromUserId);
                  if (knockerWs && knockerWs.readyState === WebSocket.OPEN) {
                    const message = accepted 
                      ? `Your knock request was accepted. You can now enter the room.`
                      : `Your knock request was rejected.`;
                    
                    // Create notification for knocker
                    await storage.createNotification({
                      userId: knockRequest.fromUserId,
                      type: 'knock_response',
                      message,
                      relatedId: room.id
                    });
                    
                    knockerWs.send(JSON.stringify({
                      type: 'knock_response',
                      data: {
                        roomId: room.id,
                        accepted,
                        message
                      }
                    }));
                    
                    // Send notifications update
                    knockerWs.send(JSON.stringify({
                      type: 'notifications_update',
                      data: {
                        notifications: await storage.getUserNotifications(knockRequest.fromUserId)
                      }
                    }));
                  }
                }
              }
            }
            break;
          }
          
          case 'room_message': {
            if (userId) {
              const roomId = msg.data.roomId;
              const message = msg.data.message;
              
              // Check if user is in the room
              const roomParticipants = await storage.getRoomParticipants(roomId);
              const isInRoom = roomParticipants.some(p => p.userId === userId);
              
              if (isInRoom) {
                const sender = await storage.getUser(userId);
                
                if (sender) {
                  // Send message to all participants in the room
                  for (const participant of roomParticipants) {
                    const clientWs = clients.get(participant.userId);
                    if (clientWs && clientWs.readyState === WebSocket.OPEN) {
                      clientWs.send(JSON.stringify({
                        type: 'room_message',
                        data: {
                          roomId,
                          message,
                          sender: {
                            id: sender.id,
                            displayName: sender.displayName,
                            avatarUrl: sender.avatarUrl
                          },
                          timestamp: new Date()
                        }
                      }));
                    }
                  }
                }
              }
            }
            break;
          }
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
    
    ws.on('close', () => {
      if (userId) {
        clients.delete(userId);
        // Update user status to offline
        storage.updateUser(userId, { status: "offline" })
          .then(user => {
            if (user) {
              broadcastUserStatus(user);
            }
          })
          .catch(console.error);
      }
    });
  });

  // Task routes
  app.get("/api/tasks", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const userId = (req.user as Express.User).id;
      const tasks = await storage.getTasksByAssignee(userId);
      res.json(tasks);
    } catch (error) {
      next(error);
    }
  });
  
  app.post("/api/tasks", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const parsedData = insertTaskSchema.safeParse(req.body);
      if (!parsedData.success) {
        return res.status(400).json({ error: "Invalid task data" });
      }
      
      const task = await storage.createTask(parsedData.data);
      
      // Create notification for assignee if it's not the creator
      if (task.assignedById !== task.assignedToId) {
        await storage.createNotification({
          userId: task.assignedToId,
          type: 'task',
          message: `You've been assigned a new task: "${task.title}"`,
          relatedId: task.id
        });
        
        // Notify assignee via WebSocket if they're online
        const assigneeWs = clients.get(task.assignedToId);
        if (assigneeWs && assigneeWs.readyState === WebSocket.OPEN) {
          assigneeWs.send(JSON.stringify({
            type: 'new_task',
            data: { task }
          }));
          
          // Also send updated notifications
          assigneeWs.send(JSON.stringify({
            type: 'notifications_update',
            data: {
              notifications: await storage.getUserNotifications(task.assignedToId)
            }
          }));
        }
      }
      
      res.status(201).json(task);
    } catch (error) {
      next(error);
    }
  });
  
  app.patch("/api/tasks/:id", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const taskId = parseInt(req.params.id);
      const userId = (req.user as Express.User).id;
      
      const task = await storage.getTask(taskId);
      if (!task) {
        return res.status(404).json({ error: "Task not found" });
      }
      
      // Only assignee or assigner can update
      if (task.assignedToId !== userId && task.assignedById !== userId) {
        return res.status(403).json({ error: "Not authorized to update this task" });
      }
      
      const updatedTask = await storage.updateTask(taskId, req.body);
      
      // If task was completed, create notification for assigner
      if (req.body.status === "completed" && task.status !== "completed" && task.assignedById !== userId) {
        await storage.createNotification({
          userId: task.assignedById,
          type: 'task_completed',
          message: `Task "${task.title}" has been completed`,
          relatedId: task.id
        });
        
        // Notify assigner via WebSocket
        const assignerWs = clients.get(task.assignedById);
        if (assignerWs && assignerWs.readyState === WebSocket.OPEN) {
          assignerWs.send(JSON.stringify({
            type: 'task_updated',
            data: { task: updatedTask }
          }));
          
          // Also send updated notifications
          assignerWs.send(JSON.stringify({
            type: 'notifications_update',
            data: {
              notifications: await storage.getUserNotifications(task.assignedById)
            }
          }));
        }
      }
      
      res.json(updatedTask);
    } catch (error) {
      next(error);
    }
  });

  // Room routes
  app.get("/api/rooms", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const userId = (req.user as Express.User).id;
      const rooms = await storage.getUserRooms(userId);
      
      // Enhance rooms with participant counts
      const enhancedRooms = await Promise.all(rooms.map(async (room) => {
        const participants = await storage.getRoomParticipants(room.id);
        return {
          ...room,
          participantCount: participants.length
        };
      }));
      
      res.json(enhancedRooms);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/rooms/:id", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const roomId = parseInt(req.params.id);
      const room = await storage.getRoom(roomId);
      
      if (!room) {
        return res.status(404).json({ error: "Room not found" });
      }
      
      // Get room participants
      const roomParticipants = await storage.getRoomParticipants(roomId);
      const participants = await Promise.all(
        roomParticipants.map(async (p) => {
          const user = await storage.getUser(p.userId);
          return user ? {
            id: user.id,
            displayName: user.displayName,
            username: user.username,
            status: user.status,
            avatarUrl: user.avatarUrl
          } : null;
        })
      );
      
      // Filter out null values
      const validParticipants = participants.filter(p => p !== null);
      
      res.json({
        ...room,
        participants: validParticipants
      });
    } catch (error) {
      next(error);
    }
  });
  
  app.post("/api/rooms", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const parsedData = insertRoomSchema.safeParse(req.body);
      if (!parsedData.success) {
        return res.status(400).json({ error: "Invalid room data" });
      }
      
      const room = await storage.createRoom(parsedData.data);
      res.status(201).json(room);
      
      // Broadcast room creation to connected clients
      broadcastRoomUpdate();
    } catch (error) {
      next(error);
    }
  });
  
  app.patch("/api/rooms/:id", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const roomId = parseInt(req.params.id);
      const userId = (req.user as Express.User).id;
      
      const room = await storage.getRoom(roomId);
      if (!room) {
        return res.status(404).json({ error: "Room not found" });
      }
      
      // Only owner or admin can update
      const user = req.user as Express.User;
      if (room.ownerId !== userId && user.role !== "admin") {
        return res.status(403).json({ error: "Not authorized to update this room" });
      }
      
      const updatedRoom = await storage.updateRoom(roomId, req.body);
      res.json(updatedRoom);
      
      // Broadcast room update to connected clients
      broadcastRoomUpdate();
    } catch (error) {
      next(error);
    }
  });

  // Meeting routes
  app.get("/api/meetings", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const userId = (req.user as Express.User).id;
      const meetings = await storage.getUpcomingMeetings(userId);
      res.json(meetings);
    } catch (error) {
      next(error);
    }
  });
  
  app.post("/api/meetings", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const parsedData = insertMeetingSchema.safeParse({
        ...req.body,
        createdById: (req.user as Express.User).id
      });
      
      if (!parsedData.success) {
        return res.status(400).json({ error: "Invalid meeting data" });
      }
      
      const meeting = await storage.createMeeting(parsedData.data);
      
      // If meeting is in a room, notify room participants
      if (meeting.roomId) {
        const roomParticipants = await storage.getRoomParticipants(meeting.roomId);
        for (const participant of roomParticipants) {
          if (participant.userId !== meeting.createdById) {
            // Create notification
            await storage.createNotification({
              userId: participant.userId,
              type: 'meeting',
              message: `New meeting scheduled: "${meeting.title}"`,
              relatedId: meeting.id
            });
            
            // Notify via WebSocket
            const clientWs = clients.get(participant.userId);
            if (clientWs && clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({
                type: 'new_meeting',
                data: { meeting }
              }));
              
              // Also send updated notifications
              clientWs.send(JSON.stringify({
                type: 'notifications_update',
                data: {
                  notifications: await storage.getUserNotifications(participant.userId)
                }
              }));
            }
          }
        }
      }
      
      res.status(201).json(meeting);
    } catch (error) {
      next(error);
    }
  });

  // User routes
  app.get("/api/users", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      let users = await storage.getAllUsers();
      
      // Don't send passwords to client
      users = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      res.json(users);
    } catch (error) {
      next(error);
    }
  });
  
  app.patch("/api/users/:id", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const userId = parseInt(req.params.id);
      const currentUser = req.user as Express.User;
      
      // Only self or admin can update
      if (userId !== currentUser.id && currentUser.role !== "admin") {
        return res.status(403).json({ error: "Not authorized to update this user" });
      }
      
      // Don't allow changing password or role through this route
      const { password, role, ...updateData } = req.body;
      
      const updatedUser = await storage.updateUser(userId, updateData);
      if (!updatedUser) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Don't send password to client
      const { password: _, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
      
      // If user's status changed, broadcast it
      if (req.body.status && updatedUser.status !== currentUser.status) {
        broadcastUserStatus(updatedUser);
      }
    } catch (error) {
      next(error);
    }
  });

  // Notification routes
  app.get("/api/notifications", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const userId = (req.user as Express.User).id;
      const notifications = await storage.getUserNotifications(userId);
      res.json(notifications);
    } catch (error) {
      next(error);
    }
  });
  
  app.patch("/api/notifications/:id/read", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const notificationId = parseInt(req.params.id);
      const userId = (req.user as Express.User).id;
      
      const notification = await storage.getNotification(notificationId);
      if (!notification) {
        return res.status(404).json({ error: "Notification not found" });
      }
      
      // Only the notification recipient can mark as read
      if (notification.userId !== userId) {
        return res.status(403).json({ error: "Not authorized to update this notification" });
      }
      
      const updatedNotification = await storage.markNotificationAsRead(notificationId);
      res.json(updatedNotification);
    } catch (error) {
      next(error);
    }
  });

  // Helper function to broadcast user status updates
  function broadcastUserStatus(user: any) {
    // Remove password
    const { password, ...userWithoutPassword } = user;
    
    for (const [_, ws] of clients.entries()) {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'user_status_update',
          data: {
            id: user.id,
            status: user.status,
            displayName: user.displayName
          }
        }));
      }
    }
  }
  
  // Helper function to broadcast room updates
  async function broadcastRoomUpdate() {
    for (const [userId, ws] of clients.entries()) {
      if (ws.readyState === WebSocket.OPEN) {
        const rooms = await storage.getUserRooms(userId);
        
        ws.send(JSON.stringify({
          type: 'rooms_update',
          data: { rooms }
        }));
      }
    }
  }

  return httpServer;
}
